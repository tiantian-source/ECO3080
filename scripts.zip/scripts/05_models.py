"""Simple pooled models, monthly expanding validation, then annual OOS fits."""
import json
import time
import hashlib
from pathlib import Path
import numpy as np
import pandas as pd
from sklearn.linear_model import LinearRegression,Lasso
from sklearn.ensemble import RandomForestRegressor
import torch
from torch import nn
from common import ROOT,sha256

CONFIG=json.loads((ROOT/'research_config.json').read_text())
FEATURES=CONFIG['features']
MODEL_NAMES=['OLS','LASSO','RF','MLP']
TABLES=ROOT/'results/tables'
PREDICTIONS=ROOT/'results/predictions'
torch.set_num_threads(1)
torch.use_deterministic_algorithms(True)

def fit_model(name,setting,x,y):
    """MLP uses full-batch Adam, fixed epochs and three predefined seeds."""
    if name=='OLS':
        return LinearRegression().fit(x,y)
    if name=='LASSO':
        return Lasso(**setting,max_iter=10000,tol=1e-8).fit(x,y)
    if name=='RF':
        return RandomForestRegressor(**setting,random_state=CONFIG['rf_seed'],
                                    max_features=1.0,n_jobs=4).fit(x,y)
    x_tensor=torch.from_numpy(np.ascontiguousarray(x,dtype=np.float32))
    # Target scaling is estimated on this training fold only and inverted.
    # This improves network optimization without changing the prediction target.
    y_mean=float(np.mean(y));y_std=float(np.std(y))
    y_tensor=torch.from_numpy(np.ascontiguousarray((np.asarray(y)-y_mean)/y_std,dtype=np.float32)).reshape(-1,1)
    networks=[]
    for seed in CONFIG['mlp_seeds']:
        torch.manual_seed(seed)
        dimensions=[len(FEATURES)]+setting['layers']+[1]
        layers=[]
        for j in range(len(dimensions)-1):
            layers.append(nn.Linear(dimensions[j],dimensions[j+1]))
            if j<len(dimensions)-2:
                layers.append(nn.ReLU())
        net=nn.Sequential(*layers)
        optimizer=torch.optim.Adam(net.parameters(),lr=setting['learning_rate'],
                                   weight_decay=setting['weight_decay'])
        for epoch in range(setting['epochs']):
            optimizer.zero_grad()
            loss=nn.functional.mse_loss(net(x_tensor),y_tensor)
            loss.backward()
            optimizer.step()
        net.eval()
        networks.append(net)
    return dict(networks=networks,y_mean=y_mean,y_std=y_std)

def predict_model(name,model,x):
    if name!='MLP':
        return model.predict(x)
    x_tensor=torch.from_numpy(np.ascontiguousarray(x,dtype=np.float32))
    with torch.no_grad():
        return np.mean([net(x_tensor).numpy().ravel() for net in model['networks']],axis=0)*model['y_std']+model['y_mean']

def available_training(panel,date):
    train=panel.loc[panel.eligible_at_formation & panel.excess_return.notna() &
                    panel.holding_month.ge('2010-01') & panel.label_available_date.le(date)].copy()
    assert train.label_available_date.max()<=date
    assert train.formation_date.max()<date
    return train

def main():
    TABLES.mkdir(parents=True,exist_ok=True)
    PREDICTIONS.mkdir(parents=True,exist_ok=True)
    status=json.loads((ROOT/'data/processed/data_status.json').read_text())
    assert status['formal_data_ready'], 'Formal eight-feature Data Readiness Gate has not passed.'
    panel=pd.read_parquet(ROOT/'data/processed/panel_monthly.parquet')
    version=sha256(ROOT/'research_config.json')[:12]
    config_hash=sha256(ROOT/'research_config.json')
    grids={'OLS':CONFIG['ols'],'LASSO':CONFIG['lasso'],'RF':CONFIG['rf'],'MLP':CONFIG['mlp']}
    fold_rows=[];validation_parts=[]
    # Every validation month is a genuine new model estimation, all Y matured.
    valid=panel.loc[panel.holding_month.between('2021-01','2022-12')&panel.eligible_at_formation]
    for month,g in valid.groupby('holding_month',sort=True):
        date=g.formation_date.iloc[0]
        train=available_training(panel,date)
        print('Validation',month,'training through',train.holding_month.max(),flush=True)
        x=train[FEATURES].to_numpy();y=train.excess_return.to_numpy()
        part=g[['formation_month','formation_date','holding_month','stock','label_available_date','excess_return']].copy()
        part['model_estimation_date']=date
        for name in MODEL_NAMES:
            for k,setting in enumerate(grids[name]):
                start=time.monotonic()
                fitted=fit_model(name,setting,x,y)
                forecast=predict_model(name,fitted,g[FEATURES].to_numpy())
                part[f'{name}_{k}']=forecast
                evaluable=g.excess_return.notna()
                mse=float(np.mean((g.loc[evaluable,'excess_return'].to_numpy()-forecast[evaluable])**2))
                fold_rows.append(dict(model=name,candidate=k,holding_month=month,
                    model_estimation_date=date,training_rows=len(train),
                    training_last_holding_month=train.holding_month.max(),
                    training_last_label_available_date=train.label_available_date.max(),
                    training_mse=float(np.mean((y-predict_model(name,fitted,x))**2)),
                    validation_mse=mse,validation_evaluable_rows=int(evaluable.sum()),
                    available_for_selection=bool(g.label_available_date.max()<=pd.Timestamp(CONFIG['hyperparameter_freeze_date'])),
                    seconds=time.monotonic()-start,setting=json.dumps(setting)))
        validation_parts.append(part)
        pd.DataFrame(fold_rows).to_csv(TABLES/'validation_folds.csv',index=False)
        pd.concat(validation_parts,ignore_index=True).to_parquet(PREDICTIONS/'validation_predictions.parquet',index=False)
    folds=pd.DataFrame(fold_rows)
    selection=folds.loc[folds.available_for_selection].groupby(['model','candidate']).validation_mse.mean().rename('selection_mse').reset_index()
    assert folds.loc[folds.available_for_selection].holding_month.nunique()==23
    selected={}
    for name in MODEL_NAMES:
        candidate=int(selection.loc[selection.model.eq(name)].sort_values(['selection_mse','candidate']).iloc[0].candidate)
        selected[name]=dict(candidate=candidate,settings=grids[name][candidate])
    selection.to_csv(TABLES/'validation_grid.csv',index=False)
    frozen=dict(freeze_date=CONFIG['hyperparameter_freeze_date'],selection_months=23,
                excluded_boundary_month='2022-12',config_sha256=config_hash,models=selected)
    (ROOT/'results/frozen_hyperparameters.json').write_text(json.dumps(frozen,indent=2))
    print('Frozen hyperparameters',json.dumps(selected),flush=True)

    oos_parts=[];estimation_rows=[];importance_rows=[];coefficients=[]
    for year in [2023,2024,2025,2026]:
        month_start=f'{year}-01';month_end=f'{year}-12' if year<2026 else '2026-01'
        test=panel.loc[panel.holding_month.between(month_start,month_end)&panel.eligible_at_formation].copy()
        date=test.loc[test.holding_month.eq(month_start),'formation_date'].iloc[0]
        train=available_training(panel,date)
        print('Annual model fit',year,'at',date.date(),'last label',train.holding_month.max(),flush=True)
        test['prediction_date']=test.formation_date
        test['model_estimation_date']=date
        test['training_sample_end']=train.holding_month.max()
        test['training_last_label_available_date']=train.label_available_date.max()
        test['model_version']=version
        test['actual_excess_return']=test.excess_return
        test['actual_raw_return']=test.raw_return
        x=train[FEATURES].to_numpy();y=train.excess_return.to_numpy()
        for name in MODEL_NAMES:
            model=fit_model(name,selected[name]['settings'],x,y)
            test[f'{name}_pred']=predict_model(name,model,test[FEATURES].to_numpy())
            estimation_rows.append(dict(year=year,model=name,estimation_date=date,
                training_rows=len(train),training_sample_end=train.holding_month.max(),
                training_last_label_available_date=train.label_available_date.max(),
                train_mse=float(np.mean((y-predict_model(name,model,x))**2)),
                settings=json.dumps(selected[name]['settings']),model_version=version))
            if name in ['OLS','LASSO']:
                for feature,coef in zip(FEATURES,model.coef_):
                    coefficients.append(dict(year=year,model=name,feature=feature,coefficient=coef,intercept=model.intercept_))
            if year<2026 and name in ['RF','MLP']:
                for month,g in test.groupby('holding_month',sort=True):
                    eval_g=g.loc[g.excess_return.notna()]
                    xt=eval_g[FEATURES].to_numpy();yt=eval_g.excess_return.to_numpy()
                    base=float(np.mean((yt-predict_model(name,model,xt))**2))
                    for feature_i,feature in enumerate(FEATURES):
                        for seed in CONFIG['permutation_seeds']:
                            rng=np.random.default_rng(seed+int(month.replace('-',''))+feature_i)
                            shuffled=xt.copy()
                            shuffled[:,feature_i]=rng.permutation(shuffled[:,feature_i])
                            delta=float(np.mean((yt-predict_model(name,model,shuffled))**2)-base)
                            importance_rows.append(dict(model=name,holding_month=month,feature=feature,seed=seed,
                                                        mse_increase=delta,observations=len(eval_g)))
        assert test.model_estimation_date.le(test.prediction_date).all()
        assert test.training_last_label_available_date.le(test.model_estimation_date).all()
        assert test[[n+'_pred' for n in MODEL_NAMES]].notna().all().all()
        if year<2026:
            oos_parts.append(test)
            pd.concat(oos_parts,ignore_index=True).to_parquet(PREDICTIONS/'oos_predictions.parquet',index=False)
        else:
            test.to_parquet(PREDICTIONS/'application_2026_01.parquet',index=False)
    oos=pd.concat(oos_parts,ignore_index=True)
    assert oos.holding_month.nunique()==36
    assert not oos.duplicated(['holding_month','stock']).any()
    pd.DataFrame(estimation_rows).to_csv(TABLES/'model_estimation_audit.csv',index=False)
    pd.DataFrame(coefficients).to_csv(TABLES/'linear_coefficients.csv',index=False)
    pd.DataFrame(importance_rows).to_csv(TABLES/'permutation_importance_monthly.csv',index=False)
    (ROOT/'results/model_run_manifest.json').write_text(json.dumps(dict(
        status='EXECUTED',config_sha256=config_hash,panel_sha256=sha256(ROOT/'data/processed/panel_monthly.parquet'),
        script_sha256=sha256(Path(__file__)),oos_observations=len(oos),oos_months=36,
        validation_months=24,selection_months=23,features=FEATURES,seeds=CONFIG['mlp_seeds']),indent=2))
    print('All four models completed',len(oos),'OOS observations',flush=True)

if __name__=='__main__':
    main()
