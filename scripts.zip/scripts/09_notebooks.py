"""Create concise executable research notebooks, sharing the actual pipeline."""
import json
from pathlib import Path
import nbformat as nbf
from common import ROOT

N=ROOT/'notebooks';N.mkdir(exist_ok=True)
init='''from pathlib import Path
import os, sys, json
os.environ['OMP_NUM_THREADS'] = '1'
os.environ['OPENBLAS_NUM_THREADS'] = '1'
ROOT = Path.cwd()
if ROOT.name == 'notebooks':
    ROOT = ROOT.parent
assert (ROOT / 'research_config.json').exists()
sys.path.insert(0, str(ROOT / 'scripts'))
import numpy as np
import pandas as pd
from IPython.display import display, Image
from common import md_table
pd.set_option('display.max_columns', 12)
TABLES = ROOT / 'results/tables'
PRED = ROOT / 'results/predictions'
'''

def write(name,title,sections):
    cells=[nbf.v4.new_markdown_cell('# '+title+'\n\n所有表格和数字读取本次实际运行产物；关键计算在下方独立核对。完整原始数据重建和模型重估命令见README。'),nbf.v4.new_code_cell(init)]
    for heading,explanation,code in sections:
        cells += [nbf.v4.new_markdown_cell('## '+heading+'\n\n'+explanation),nbf.v4.new_code_cell(code)]
    nb=nbf.v4.new_notebook(cells=cells,metadata={'kernelspec':{'display_name':'ECO3080 quant (existing)','language':'python','name':'eco3080-quant'},'language_info':{'name':'python','version':'3.12'}})
    nbf.write(nb,N/name)

write('01_data_audit.ipynb','01 — 原始数据审计与RQData补充',[
 ('文件与重复','原文件保留。哈希清单和ZIP逐成员记录可用于追踪来源，避免按文件名猜数据。',
 '''manifest = pd.read_csv(ROOT / 'reports/audit/original_file_manifest.csv')
inventory = pd.read_csv(ROOT / 'reports/audit/pkl_inventory.csv')
display(pd.DataFrame({'original_files':[len(manifest)], 'PKL':[len(inventory)], 'bytes':[manifest.bytes.sum()]}))
display(inventory[['filename','rows','columns','date_start','date_end','missing_share','memory_MiB']])'''),
 ('ZIP和实际字段','名为日个股回报率的ZIP实际只下载了涨跌停状态，不能当收益数据。',
 '''members = pd.read_csv(ROOT / 'reports/audit/zip_members.csv')
display(members.groupby('archive').agg(members=('member','size'),bytes=('bytes','sum')))
detail = json.loads((ROOT / 'reports/audit/csv_details.json').read_text())
next(({'file':k,'columns':v['columns']} for k,v in detail.items() if 'TRD_Dalyr.csv' in k))'''),
 ('来源重叠与PIT','get_factor的历史PIT约定与原始版本/公式检查共同支持主财务变量。if_adjusted不是更正标志。',
 '''display(pd.read_csv(ROOT / 'reports/audit/rqdata_factor_crosscheck.csv'))
checks = pd.read_csv(ROOT / 'reports/audit/pit_formula_crosschecks.csv')
display(checks.groupby('field').agg(checks=('relative_error','size'),max_error=('relative_error','max')))
assert checks.relative_error.max() < 1e-6
json.loads((ROOT / 'data/processed/data_status.json').read_text())''')])

write('02_panel_construction.ipynb','02 — 历史股票月面板和时间对齐',[
 ('形成日和成员','193个月各从真实历史500只成员开始。合格筛选只使用形成时已知数据。',
 '''panel = pd.read_parquet(ROOT / 'data/processed/panel_monthly.parquet')
assert not panel.duplicated(['formation_month','stock']).any()
assert panel.groupby('holding_month').size().eq(500).all()
display(panel.groupby('holding_month').agg(members=('stock','size'),eligible=('eligible_at_formation','sum')).iloc[[0,131,155,191,192]])
display(panel[['formation_month','formation_date','holding_month','entry_date','exit_date','label_available_date']].drop_duplicates().tail(5))'''),
 ('手算收益及Momentum','价格必须是规定市场日期；不能寻找股票下次交易日。已有原价端点一并保留，下面直接除法复核。',
 '''sample = panel.loc[panel.eligible_at_formation].groupby('holding_month').head(1).iloc[[0,120,156,192]]
assert np.allclose(sample.exit_adj_close / sample.entry_adj_close - 1, sample.raw_return)
assert np.allclose(sample.momentum_end_price / sample.momentum_start_price - 1, sample.momentum_raw)
assert np.allclose(sample.raw_return - sample.rf_return, sample.excess_return)
display(sample[['holding_month','stock','entry_adj_close','exit_adj_close','raw_return','momentum_raw']])'''),
 ('横截面排名和标签截止','排序先于未来收益筛选；偶发财务缺失置中性0，整个因子月缺失则停止。所有训练按label_available_date检查。',
 '''FEATURES = json.loads((ROOT / 'research_config.json').read_text())['features']
g = panel.loc[panel.formation_month.eq('2022-12') & panel.eligible_at_formation]
for feature in FEATURES:
    values = g[feature + '_raw']
    n = values.notna().sum()
    expected = (2 * (values.rank(method='average') - 1) / (n - 1) - 1).fillna(0)
    assert np.allclose(expected, g[feature])
display(pd.read_csv(TABLES / 'feature_coverage.csv'))
display(pd.read_csv(TABLES / 'model_estimation_audit.csv')[['year','model','estimation_date','training_sample_end','training_last_label_available_date']])''')])

write('03_ols_lasso.ipynb','03 — OLS、LASSO与逐月扩展验证',[
 ('统一训练与23个月冻结边界','完整训练脚本05_models.py同时运行四模型；验证按月重估。2022-12仅描述，不参加2022-12-30的参数选择。',
 '''from importlib import import_module
models = import_module('05_models')
config = json.loads((ROOT / 'research_config.json').read_text())
folds = pd.read_csv(TABLES / 'validation_folds.csv')
display(pd.read_csv(TABLES / 'validation_grid.csv').query("model in ['OLS','LASSO']"))
display(folds.query("model == 'OLS'")[['holding_month','training_last_holding_month','available_for_selection','training_mse','validation_mse']])
assert folds.loc[folds.available_for_selection].holding_month.nunique() == 23
RUN_FULL_TRAINING = False  # 改为True可重新运行全部共同样本模型；约数分钟。
if RUN_FULL_TRAINING:
    models.main()'''),
 ('OLS独立最小二乘核对','不读取测试Y进行调参。以首个验证月为例，对照NumPy的解析最小二乘预测。',
 '''panel = pd.read_parquet(ROOT / 'data/processed/panel_monthly.parquet')
tr = models.available_training(panel, pd.Timestamp('2020-12-31'))
va = panel.loc[panel.holding_month.eq('2021-01') & panel.eligible_at_formation]
X, y = tr[models.FEATURES].to_numpy(), tr.excess_return.to_numpy()
ols = models.fit_model('OLS', {}, X, y)
beta = np.linalg.lstsq(np.column_stack([np.ones(len(X)),X]), y, rcond=None)[0]
forecast_a = ols.predict(va[models.FEATURES].to_numpy())
forecast_b = np.column_stack([np.ones(len(va)),va[models.FEATURES].to_numpy()]) @ beta
assert np.max(abs(forecast_a-forecast_b)) < 1e-12
print('Maximum prediction difference:', np.max(abs(forecast_a-forecast_b)))
display(pd.read_csv(TABLES / 'linear_coefficients.csv').query("model == 'LASSO'").pivot(index='feature',columns='year',values='coefficient'))''')])

write('04_random_forest.ipynb','04 — Random Forest',[
 ('设定、验证和冻结','小网格在research_config.json中事前固定。测试期树数与验证候选完全一致。',
 '''config = json.loads((ROOT / 'research_config.json').read_text())
frozen = json.loads((ROOT / 'results/frozen_hyperparameters.json').read_text())
display(pd.DataFrame(config['rf']))
display(pd.read_csv(TABLES / 'validation_grid.csv').query("model == 'RF'"))
frozen['models']['RF']'''),
 ('首年模型抽样复现','按2022-12-30可见标签重新拟合冻结设定，核对保存的2023年预测。该核对不重选参数。',
 '''from importlib import import_module
models = import_module('05_models')
panel = pd.read_parquet(ROOT / 'data/processed/panel_monthly.parquet')
tr = models.available_training(panel, pd.Timestamp('2022-12-30'))
saved = pd.read_parquet(PRED / 'oos_predictions.parquet').query("holding_month == '2023-01'").head(5)
fit = models.fit_model('RF', frozen['models']['RF']['settings'], tr[models.FEATURES].to_numpy(), tr.excess_return.to_numpy())
replicated = models.predict_model('RF', fit, saved[models.FEATURES].to_numpy())
assert np.allclose(replicated, saved.RF_pred, atol=1e-12)
display(pd.DataFrame({'stock':saved.stock,'saved_prediction':saved.RF_pred,'reproduced':replicated}))
display(pd.read_csv(TABLES / 'feature_importance.csv').query("model == 'RF'").sort_values('mean',ascending=False))''')])

write('05_mlp.ipynb','05 — 三种子MLP',[
 ('小网络与固定训练长度','ReLU、全批次Adam；训练Y缩放只用训练fold统计量，再还原预测。没有随机验证分组或测试早停。',
 '''config = json.loads((ROOT / 'research_config.json').read_text())
frozen = json.loads((ROOT / 'results/frozen_hyperparameters.json').read_text())
display(pd.DataFrame(config['mlp']))
print('Predefined seeds:', config['mlp_seeds'])
display(pd.read_csv(TABLES / 'validation_grid.csv').query("model == 'MLP'"))
frozen['models']['MLP']'''),
 ('三种子平均预测抽样复现','重新拟合首年冻结设定，检查保存值。这只验证可复现性，不利用核对结果改模型。',
 '''from importlib import import_module
models = import_module('05_models')
panel = pd.read_parquet(ROOT / 'data/processed/panel_monthly.parquet')
tr = models.available_training(panel, pd.Timestamp('2022-12-30'))
saved = pd.read_parquet(PRED / 'oos_predictions.parquet').query("holding_month == '2023-01'").head(5)
fit = models.fit_model('MLP', frozen['models']['MLP']['settings'], tr[models.FEATURES].to_numpy(), tr.excess_return.to_numpy())
replicated = models.predict_model('MLP', fit, saved[models.FEATURES].to_numpy())
assert np.allclose(replicated, saved.MLP_pred, atol=2e-8)
display(pd.DataFrame({'stock':saved.stock,'saved_prediction':saved.MLP_pred,'reproduced':replicated}))
display(pd.read_csv(TABLES / 'feature_importance.csv').query("model == 'MLP'").sort_values('mean',ascending=False))''')])

write('06_prediction_evaluation.ipynb','06 — OOS预测与Newey–West',[
 ('零预测基准','四模型使用同一批实际标签；不用默认r2_score替代Proposal公式。',
 '''oos = pd.read_parquet(PRED / 'oos_predictions.parquet')
assert oos.holding_month.nunique() == 36
assert not oos.duplicated(['holding_month','stock']).any()
saved = pd.read_csv(TABLES / 'model_performance.csv').set_index('model')
for model in ['OLS','LASSO','RF','MLP']:
    y, forecast = oos.actual_excess_return, oos[model+'_pred']
    r2 = 1 - ((y-forecast)**2).sum() / (y**2).sum()
    assert np.isclose(r2,saved.loc[model,'oos_r2'])
display(saved)'''),
 ('独立核对HAC方差和p值','36个按月平均损失差，Bartlett lag3、小样本校正n/(n−1)。t分布df35。',
 '''from scipy.stats import t as student_t
comparisons = pd.read_csv(TABLES / 'forecast_comparison.csv').set_index('model')
rows = []
for model in ['LASSO','RF','MLP']:
    d = ((oos.actual_excess_return-oos.OLS_pred)**2 - (oos.actual_excess_return-oos[model+'_pred'])**2).groupby(oos.holding_month).mean().to_numpy()
    n, lag = len(d), 3
    u = d-d.mean()
    long_variance = np.dot(u,u)/n
    for j in range(1,lag+1):
        long_variance += 2*(1-j/(lag+1))*np.dot(u[j:],u[:-j])/n
    se = np.sqrt(long_variance/n*n/(n-1))
    statistic = d.mean()/se
    p_value = 2*student_t.sf(abs(statistic),df=n-1)
    assert np.isclose(se,comparisons.loc[model,'nw_standard_error'])
    assert np.isclose(p_value,comparisons.loc[model,'p_value'])
    rows.append({'model':model,'months':n,'manual_NW_SE':se,'manual_p_value':p_value})
display(pd.DataFrame(rows))
display(comparisons)
display(Image(filename=str(ROOT/'results/figures/prediction_performance.png')))''')])

write('07_portfolio_backtest.ipynb','07 — 十分位组合、换手与历史应用',[
 ('固定预测形成组合','此处只读取已保存OOS预测，不重新调参。回报是实际调整价格收益。',
 '''weights = pd.read_parquet(PRED / 'portfolio_weights.parquet')
returns = pd.read_csv(TABLES / 'decile_returns.csv')
assert np.allclose(weights.groupby(['holding_month','model','portfolio']).weight.sum(),1)
computed = (weights.weight*weights.raw_return).groupby([weights.holding_month,weights.model,weights.portfolio]).sum()
reported = returns.set_index(['holding_month','model','portfolio']).raw_return
assert np.allclose(computed.sort_index(),reported.sort_index())
display(pd.read_csv(TABLES/'portfolio_performance.csv'))
display(Image(filename=str(ROOT/'results/figures/cumulative_d10.png')))'''),
 ('初始净值、漂移换手与假设成本','最大回撤必须含期初1；换手先随上期收益漂移。实际成交未被观察，停牌/限价计数另列。',
 '''portfolio = pd.read_csv(TABLES/'portfolio_performance.csv')
for model in ['OLS','LASSO','RF','MLP','EW','VW']:
    label = 'D10' if model in ['OLS','LASSO','RF','MLP'] else 'ALL'
    r = returns.loc[returns.model.eq(model)&returns.portfolio.eq(label)].sort_values('holding_month')
    wealth = np.r_[1.,(1+r.raw_return).cumprod().to_numpy()]
    mdd = (wealth/np.maximum.accumulate(wealth)-1).min()
    saved = portfolio.loc[portfolio.model.eq(model)&portfolio.portfolio.eq(label)].iloc[0]
    assert np.isclose(mdd,saved.maximum_drawdown)
display(pd.read_csv(TABLES/'trading_feasibility_summary.csv'))
display(pd.read_csv(TABLES/'transaction_cost_sensitivity.csv')[['model','assumed_cost_bps','annualized_return','sharpe']])'''),
 ('January 2026独立应用','使用2025-12末信息及已实现至2025-11的标签；此月不进入模型选择或主36个月测试。',
 '''application = pd.read_parquet(PRED/'application_2026_01.parquet')
assert application.training_sample_end.eq('2025-11').all()
assert application.training_last_label_available_date.le(application.model_estimation_date).all()
display(application[['formation_date','entry_date','exit_date','training_sample_end']].drop_duplicates())
display(pd.read_csv(TABLES/'application_portfolio.csv'))
display(pd.read_csv(TABLES/'application_d10_holdings.csv').head(10))
display(Image(filename=str(ROOT/'results/figures/feature_importance.png')))''')])

# Workspace-local kernelspec; never install/overwrite a user kernel or SDK env.
kernel=ROOT/'tmp/jupyter/kernels/eco3080-quant';kernel.mkdir(parents=True,exist_ok=True)
(kernel/'kernel.json').write_text(json.dumps(dict(argv=['/opt/anaconda3/envs/quant/bin/python','-m','ipykernel_launcher','-f','{connection_file}'],
    display_name='ECO3080 quant (existing)',language='python',
    env={'OMP_NUM_THREADS':'1','OPENBLAS_NUM_THREADS':'1','MPLCONFIGDIR':str(ROOT/'tmp/matplotlib')}),indent=2))
print('Created seven notebooks and workspace-local kernelspec')
