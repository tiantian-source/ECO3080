"""Rebuild the audit panel from original inputs; never certify unverified finance."""
import gc
import json
import numpy as np
import pandas as pd
from common import source_path, LOCAL_ROOT, ROOT, AUDIT, load_local

OUT = ROOT/'data/processed'
OUT.mkdir(parents=True, exist_ok=True)
summary = {}

price = load_local('daily_adj_close_post_20260630.pkl').sort_index()
price_paths=sorted((ROOT/'data/raw/rqdata').glob('prices_20*.parquet'))
if len(price_paths)==19:
    # All research prices use one newly retrieved RQData vintage. Keep the
    # original market-date index; explicitly absent source quotes stay missing.
    price.loc['2008-12-01':'2026-02-02',:]=np.nan
    for path in price_paths:
        observations=pd.read_parquet(path).reset_index()
        observations['stock']=observations.order_book_id.str.replace('.XSHG','.SH',regex=False).str.replace('.XSHE','.SZ',regex=False)
        matrix=observations.pivot(index='date',columns='stock',values='close')
        columns=matrix.columns.intersection(price.columns)
        price.loc[matrix.index,columns]=matrix[columns]
CODE_CHANGE_DATE = pd.Timestamp('2025-02-17')

def bridge_codes(matrix):
    """Same shares, new exchange code; documented issuer announcement 2025-028.

    This joins the same security across a code change, not two securities from
    an absorption merger. The source rows and original files are preserved.
    """
    if {'300114.SZ','302132.SZ'} <= set(matrix.columns):
        dates=matrix.index.to_timestamp('M') if isinstance(matrix.index,pd.PeriodIndex) else matrix.index
        series=matrix['300114.SZ'].where(dates<CODE_CHANGE_DATE,matrix['302132.SZ'])
        matrix['300114.SZ']=series
        matrix['302132.SZ']=series
    return matrix

price=bridge_codes(price)
calendar = price.index
months = calendar.to_period('M')
first = pd.Series(calendar, index=months).groupby(level=0).min()
last = pd.Series(calendar, index=months).groupby(level=0).max()
formations = pd.period_range('2009-12','2025-12',freq='M')
daily_u = load_local('daily_csi500_components.pkl')
monthly_u = load_local('csi500_mask_monthly.pkl')
extra = pd.read_csv(source_path('csi500_components_2025_missing.csv'),parse_dates=['formation_date','source_update_date'])
assert not extra.duplicated(['formation_date','stock']).any()
assert extra.groupby('formation_date').stock.nunique().eq(500).all()
assert extra.source_update_date.le(extra.formation_date).all()
assert (extra.formation_date-extra.source_update_date).dt.days.le(7).all()
overlap = []
for date, row in monthly_u.iterrows():
    day = last.loc[date.to_period('M')]
    a=set(row.index[row.eq(True)])
    b=set(daily_u.columns[daily_u.loc[day].eq(True)])
    overlap.append(dict(formation_month=str(date.to_period('M')), symmetric_difference=len(a^b),
                        daily_only=';'.join(sorted(b-a)),monthly_only=';'.join(sorted(a-b))))
pd.DataFrame(overlap).to_csv(AUDIT/'membership_overlap.csv',index=False)
# The monthly mask replaces historical codes with successor codes in
# 2007-01..2010-06. Use the contemporaneous-code DAILY source for the pilot,
# retain this discrepancy for source verification rather than overwrite either.
assert all(set(x['daily_only'].split(';')) <= {'','000022.SZ','000043.SZ'} and
           set(x['monthly_only'].split(';')) <= {'','001872.SZ','001914.SZ'} for x in overlap)

parts=[]
rq_membership_checks=[]
for month in formations:
    formation=last[month]
    if formation<=daily_u.index.max():
        stocks=daily_u.columns[daily_u.loc[formation].eq(True)].tolist()
        source='daily_csi500_components.pkl'
        source_date=formation
    else:
        sub=extra.loc[extra.formation_date.eq(formation)]
        stocks=sub.stock.tolist()
        source='csi500_components_2025_missing.csv (BaoStock snapshot)'
        source_date=sub.source_update_date.iloc[0]
    rq_path=ROOT/'data/raw/rqdata'/f'members_{month}.parquet'
    if rq_path.exists():
        rq_stocks=pd.read_parquet(rq_path).order_book_id.str.replace('.XSHG','.SH',regex=False).str.replace('.XSHE','.SZ',regex=False).tolist()
        rq_membership_checks.append(dict(formation_month=str(month),rq_only=';'.join(sorted(set(rq_stocks)-set(stocks))),
                                         local_only=';'.join(sorted(set(stocks)-set(rq_stocks)))))
        stocks=rq_stocks
        source='RQData index_components(000905.XSHG, explicit formation date)'
        source_date=formation
    assert len(stocks)==500 and len(set(stocks))==500
    parts.append(pd.DataFrame(dict(stock=sorted(stocks),formation_month=str(month),
          formation_date=formation,holding_month=str(month+1),entry_date=first[month+1],
          exit_date=first[month+2],label_available_date=first[month+2],
          membership_source=source,membership_source_date=source_date)))
panel=pd.concat(parts,ignore_index=True)
pd.DataFrame(rq_membership_checks).to_csv(AUDIT/'rqdata_membership_crosscheck.csv',index=False)
panel['membership_original_stock']=panel.stock
panel.loc[panel.stock.eq('300114.SZ')&panel.formation_date.ge(CODE_CHANGE_DATE),'stock']='302132.SZ'
assert not panel.duplicated(['formation_month','stock']).any()
stocks=sorted(panel.stock.unique())
summary['universe_stocks']=len(stocks)
summary['membership_overlap_months']=len(overlap)
summary['membership_disagreement_months']=sum(x['symmetric_difference']>0 for x in overlap)
summary['formation_months']=len(formations)
summary['members_per_month']=500
summary['price_vintage']='RQData refreshed research histories' if len(price_paths)==19 else 'local original snapshot'
summary['missing_price_columns']=sorted(set(stocks)-set(price.columns))
price=price.reindex(columns=stocks)

def sample(matrix, dates):
    """Take exact date/code cells. Never seek a later stock-specific trade date."""
    labels = pd.PeriodIndex(dates, freq='M') if isinstance(matrix.index, pd.PeriodIndex) else pd.DatetimeIndex(dates)
    rows=matrix.index.get_indexer(labels)
    cols=matrix.columns.get_indexer(panel.stock)
    valid=(rows>=0)&(cols>=0)
    out=np.full(len(panel),np.nan)
    out[valid]=matrix.to_numpy()[rows[valid],cols[valid]]
    return out

pm=price.loc[last.values].copy()
pm.index=last.index
fm=pd.PeriodIndex(panel.formation_month,freq='M')
panel['formation_adj_close']=sample(price,panel.formation_date)
panel['entry_adj_close']=sample(price,panel.entry_date)
panel['exit_adj_close']=sample(price,panel.exit_date)
panel['raw_return']=panel.exit_adj_close/panel.entry_adj_close-1
panel['momentum_start_price']=sample(pm,fm-12)
panel['momentum_end_price']=sample(pm,fm-1)
panel['momentum_raw']=panel.momentum_end_price/panel.momentum_start_price-1
panel['reversal_raw']=-(panel.formation_adj_close/panel.momentum_end_price-1)
daily_returns=price.pct_change(fill_method=None)
panel['volatility_raw']=sample(daily_returns.rolling(21,min_periods=21).std(ddof=1),panel.formation_date)
panel['valid_price_days_252']=sample(price.notna().astype(float).rolling(252,min_periods=252).sum(),panel.formation_date)

# Verify hand-calculated examples before processing remaining inputs.
manual=[]
for month,stock in [('2009-12','000005.SZ'),('2022-12','600004.SH'),('2025-12','000009.SZ')]:
    record=panel.loc[panel.formation_month.eq(month)&panel.stock.eq(stock)]
    if record.empty:
        record=panel.loc[panel.formation_month.eq(month)].iloc[[0]]
    r=record.iloc[0]
    p0=price.at[r.entry_date,r.stock];p1=price.at[r.exit_date,r.stock]
    m=pd.Period(month,freq='M')
    p12=price.at[last[m-12],r.stock];p2=price.at[last[m-1],r.stock]
    assert np.isclose(p1/p0-1,r.raw_return,equal_nan=True)
    assert np.isclose(p2/p12-1,r.momentum_raw,equal_nan=True)
    manual.append(dict(formation_month=month,stock=r.stock,formation_date=r.formation_date,
       entry_date=r.entry_date,exit_date=r.exit_date,entry_price=p0,exit_price=p1,
       raw_return=r.raw_return,momentum_start_date=last[m-12],momentum_end_date=last[m-1],
       momentum_start_price=p12,momentum_end_price=p2,momentum=r.momentum_raw))
pd.DataFrame(manual).to_csv(AUDIT/'manual_price_checks.csv',index=False)
del daily_returns,pm,price,daily_u,monthly_u
gc.collect()

for name,column,kind in [
 ('daily_a_share_market_val_3_20260630.pkl','market_cap','value'),
 ('daily_book_to_market_ratio_ttm_20260630.pkl','bm_unverified','value'),
 ('monthly_ep_ratio_ttm_20260630.pkl','ep_unverified','monthly'),
 ('monthly_return_on_asset_net_profit_ttm_20260630.pkl','roa_unverified','monthly'),
 ('daily_turnover_rate_20260630.pkl','turnover_raw','rolling'),
 ('daily_total_money_amount_20260630.pkl','formation_trading_amount','value'),
 ('stock_st_flag_20260630.pkl','st','flag'),
 ('stock_suspend_flag_20260630.pkl','suspend','flag'),
 ('daily_limit_up_flag_20260630.pkl','limit_up','flag'),
 ('daily_limit_down_flag_20260630.pkl','limit_down','flag'),
 ('new_stock_flag_20260630.pkl','new_stock','flag')]:
    print('Sampling',name,flush=True)
    d=bridge_codes(load_local(name)).reindex(columns=stocks)
    if kind=='monthly':
        d.index=d.index.to_period('M')
        panel[column]=sample(d,fm)
    elif kind=='rolling':
        d=d.reindex(calendar)
        panel[column]=sample(d.rolling(21,min_periods=21).mean(),panel.formation_date)
    elif kind=='flag':
        # NaN remains unknown, rather than silently becoming False.
        for prefix in ['formation','entry','exit']:
            panel[f'{prefix}_{column}']=sample(d,panel[f'{prefix}_date'])
    else:
        panel[column]=sample(d,panel.formation_date)
    del d
    gc.collect()
panel['size_raw']=np.log(panel.market_cap.where(panel.market_cap>0))

# Rate metadata explicitly specifies annual -> daily compounding with a 365 basis.
rf_path=next(p for p in LOCAL_ROOT.glob('无风险利率文件224152126*/*csv'))
rf=pd.read_csv(rf_path,parse_dates=['Clsdt']).set_index('Clsdt')
assert not rf.index.duplicated().any()
assert rf.Nrr1.eq('NRI01').all()
assert rf.index.equals(pd.date_range(rf.index.min(),rf.index.max(),freq='D'))
rf_records=[]
for holding,g in panel.groupby('holding_month',sort=True):
    entry,exit=g.entry_date.iloc[0],g.exit_date.iloc[0]
    days=pd.date_range(entry,exit-pd.Timedelta(days=1),freq='D')
    rates=rf.reindex(days).Nrrdata
    assert rates.notna().all(),holding
    ret=np.expm1(np.log1p(rates/100).sum()/365)
    rf_records.append(dict(holding_month=holding,entry_date=entry,exit_date=exit,
                          calendar_days=len(days),rf_return=ret))
rf_periods=pd.DataFrame(rf_records)
rf_periods.to_csv(AUDIT/'risk_free_holding_periods.csv',index=False)
panel=panel.merge(rf_periods[['holding_month','rf_return']],on='holding_month',validate='many_to_one')
panel['excess_return']=panel.raw_return-panel.rf_return
summary['rf_annual_range']=[float(rf.Nrrdata.min()),float(rf.Nrrdata.max())]

# CSMAR packages named "Daily Stock Returns" contain ONLY limit status here.
# Keep exact-code/date matches for three relevant endpoints, read in chunks.
needed_dates=set(panel.entry_date)|set(panel.exit_date)|set(panel.formation_date)
limit_parts=[]
for path in sorted((ROOT/'data/raw/csmar').rglob('TRD_Dalyr*.csv')):
    for chunk in pd.read_csv(path,dtype={'Stkcd':'string'},chunksize=200000):
        dates=pd.to_datetime(chunk.Trddt)
        keep=dates.isin(needed_dates)
        sub=chunk.loc[keep].copy()
        sub['date']=dates[keep]
        sub['stock']=sub.Stkcd+'.'+np.where(sub.Stkcd.str.startswith('6'),'SH','SZ')
        sub=sub.loc[sub.stock.isin(stocks),['date','stock','LimitStatus']]
        limit_parts.append(sub)
limit=pd.concat(limit_parts,ignore_index=True)
conflicts=limit.groupby(['date','stock']).LimitStatus.nunique().gt(1)
assert not conflicts.any()
limit=limit.drop_duplicates(['date','stock']).set_index(['date','stock'])
for prefix in ['formation','entry','exit']:
    key=pd.MultiIndex.from_arrays([panel[f'{prefix}_date'],panel.stock],names=['date','stock'])
    panel[f'{prefix}_csmar_limit']=limit.reindex(key).LimitStatus.to_numpy()
pd.DataFrame([dict(endpoint=p,
    matched=int(panel[f'{p}_csmar_limit'].notna().sum()),
    up_disagreements=int(((panel[f'{p}_csmar_limit'].eq(1)!=panel[f'{p}_limit_up'].eq(1))&panel[f'{p}_csmar_limit'].notna()).sum()),
    down_disagreements=int(((panel[f'{p}_csmar_limit'].eq(-1)!=panel[f'{p}_limit_down'].eq(1))&panel[f'{p}_csmar_limit'].notna()).sum()))
    for p in ['formation','entry','exit']]).to_csv(AUDIT/'limit_flag_crosscheck.csv',index=False)

features=['momentum','reversal','size','turnover','volatility']
panel['minimum_history_pass']=(panel.valid_price_days_252.eq(252)&
    panel[[f'{x}_raw' for x in features]].notna().all(axis=1)&
    panel.momentum_start_price.gt(0)&panel.momentum_end_price.gt(0))
panel['eligible_at_formation']=(panel.minimum_history_pass&panel.formation_st.eq(0)&
     panel.formation_suspend.eq(0)&panel.formation_trading_amount.gt(0))
panel['pit_financial_verified']=False
panel['formal_data_ready']=False
panel['price_adjustment_convention_verified']=False
panel['label_evaluable']=panel.excess_return.notna()
# Ex-ante ranks use ALL eligible stocks, including stocks whose future y is missing.
for feature in features:
    panel[feature]=np.nan
    for month,g in panel.loc[panel.eligible_at_formation].groupby('formation_month'):
        s=g[f'{feature}_raw']
        n=s.notna().sum()
        assert n>1
        panel.loc[g.index,feature]=(2*(s.rank(method='average')-1)/(n-1)-1).fillna(0)
panel['feature_information_cutoff']=panel.formation_date
panel['panel_status']='PROVISIONAL_MARKET_PILOT_ONLY'
assert (panel.feature_information_cutoff<=panel.formation_date).all()
assert (panel.formation_date<panel.entry_date).all()
assert (panel.entry_date<panel.exit_date).all()
assert panel.label_available_date.eq(panel.exit_date).all()
assert not panel.duplicated(['formation_month','stock']).any()
assert panel.groupby('formation_month').size().eq(500).all()

prior=pd.read_csv(source_path('csi500_stock_month.csv'))
prior['formation_date']=pd.to_datetime(prior.formation_date)
comparison=panel.merge(prior,on=['stock','formation_date'],suffixes=('','_prior'),validate='one_to_one')
checks=[]
for rebuilt,old in [('raw_return','stock_return'),('momentum_raw','momentum'),
                    ('reversal_raw','reversal'),('volatility_raw','volatility'),('turnover_raw','turnover')]:
    b=old+'_prior' if old in panel.columns else old
    a=comparison[rebuilt];v=comparison[b]
    finite=a.notna()&v.notna()
    checks.append(dict(variable=rebuilt,overlap_rows=int(finite.sum()),
       max_abs_difference=float((a[finite]-v[finite]).abs().max()),
       disagreements_gt_1e_8=int(((a-v).abs()>1e-8).sum())))
pd.DataFrame(checks).to_csv(AUDIT/'prior_panel_crosscheck.csv',index=False)

finance=pd.read_csv(source_path('financial_report_audit.csv'),dtype={'Stkcd':'string'})
summary['financial_merged_rows']=len(finance)
summary['financial_missing_annodt']=int(finance.Annodt.isna().sum())
summary['financial_pre2010_rows']=int(finance.Accper.lt('2010-01-01').sum())
summary['financial_consolidated_duplicate_keys']=int(finance.loc[finance.Typrep.eq('A')].duplicated(['Stkcd','Accper']).sum())
finance.loc[finance.Typrep.eq('A')&finance.Annodt.isna()].head(30).to_csv(AUDIT/'financial_missing_annodt_examples.csv',index=False)

monthly=panel.groupby('holding_month').agg(members=('stock','size'),
    eligible=('eligible_at_formation','sum'),missing_labels=('excess_return',lambda x:x.isna().sum()))
for col in [f'{x}_raw' for x in features]+['bm_unverified','ep_unverified','roa_unverified']:
    monthly[col+'_missing']=panel.groupby('holding_month')[col].apply(lambda x:x.isna().sum())
monthly.to_csv(AUDIT/'monthly_panel_counts.csv')
panel.loc[~panel.label_evaluable].to_csv(AUDIT/'missing_return_labels.csv',index=False)
panel.loc[panel.raw_return.abs().gt(1)].to_csv(AUDIT/'extreme_return_labels.csv',index=False)
summary.update(rows=len(panel),eligible_rows=int(panel.eligible_at_formation.sum()),
    missing_labels=int((~panel.label_evaluable).sum()),
    eligible_missing_labels=int((panel.eligible_at_formation&~panel.label_evaluable).sum()),
    extreme_abs_returns_gt100pct=int(panel.raw_return.abs().gt(1).sum()),
    panel_start=panel.holding_month.min(),panel_end=panel.holding_month.max())
for split,start,end in [('train','2010-01','2020-12'),('validation','2021-01','2022-12'),
                         ('test','2023-01','2025-12'),('application','2026-01','2026-01')]:
    sub=panel.loc[panel.holding_month.between(start,end)]
    summary[split]=dict(members=len(sub),eligible=int(sub.eligible_at_formation.sum()),
                       missing_eligible_labels=int((sub.eligible_at_formation&~sub.label_evaluable).sum()))
panel.to_parquet(OUT/'panel_monthly.parquet',index=False)
(OUT/'data_status.json').write_text(json.dumps(dict(formal_data_ready=False,
    status='PROVISIONAL_MARKET_PILOT_ONLY',formal_features=['momentum','reversal','bm','ep','size','roa','turnover','volatility'],
    pilot_features=features,blocked_by=['Financial PIT and revision history','Price corporate-action convention documentation'],
    summary=summary),ensure_ascii=False,indent=2))
(AUDIT/'panel_summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2))
print(json.dumps(summary,ensure_ascii=False,indent=2))
