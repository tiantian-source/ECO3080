"""Run with the EXISTING RiceQuant Python. Never read or print license values."""
import sys
import json
import inspect
from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo
import rqdatac
import pandas as pd

# Both environments use Python 3.12. Reuse only the existing Arrow binary
# for Parquet, after RQData and its pandas/NumPy have already been imported.
# No SDK/configuration installation or change is made.
sys.path.append('/opt/anaconda3/envs/quant/lib/python3.12/site-packages')
import pyarrow
import pyarrow.parquet as pq

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'data/raw/rqdata'
OUT.mkdir(parents=True,exist_ok=True)
rqdatac.init()
status=dict(rqdatac_version=rqdatac.__version__,python=sys.version.split()[0],
            executable=sys.executable,retrieved_at=datetime.now(ZoneInfo('Asia/Shanghai')).isoformat(),
            endpoints={})

def probe(name,func,**kwargs):
    path=OUT/(name+'.parquet')
    if path.exists():
        d=pq.read_table(path).to_pandas()
    else:
        try:
            d=func(**kwargs)
        except Exception as exc:
            # Provider errors can include connection/auth strings. Log type only.
            status['endpoints'][name]=dict(status='ERROR',error_type=type(exc).__name__,parameters=kwargs)
            print(name,type(exc).__name__,flush=True)
            return
        if isinstance(d,list):
            d=pd.DataFrame({'value':d})
        if not isinstance(d,pd.DataFrame) or d.empty:
            status['endpoints'][name]=dict(status='EMPTY',parameters=kwargs)
            return
        pq.write_table(pyarrow.Table.from_pandas(d),path)
    status['endpoints'][name]=dict(status='OK',rows=len(d),columns=list(d.columns),parameters=kwargs)
    print(name,d.shape, d.head(2).to_string(),flush=True)

probe('price_probe_none',rqdatac.get_price,order_book_ids='000001.XSHE',
      start_date='2026-10-12',end_date='2026-10-16',frequency='1d',fields=['close'],adjust_type='none')
probe('factor_names',rqdatac.get_all_factor_names)
for date in ['2009-12-31','2022-12-30','2025-12-31']:
    probe('factor_probe_'+date,rqdatac.get_factor,order_book_ids=['000005.XSHE','600004.XSHG'],
          factor=['book_to_market_ratio_ttm','ep_ratio_ttm','return_on_asset_net_profit_ttm',
                  'a_share_market_val_3','market_cap_3','net_profit_ttm_0','total_assets_ttm_0',
                  'equity_parent_company_ttm_0','net_profit_parent_company_ttm_0'],
          start_date=date,end_date=date)
probe('pit_versions_probe',rqdatac.get_pit_financials_ex,
      order_book_ids=['000005.XSHE','600004.XSHG'],
      fields=['net_profit','net_profit_parent_company','total_assets','equity_parent_company'],
      start_quarter='2021q1',end_quarter='2022q4',date='2022-12-30',statements='all')
probe('members_probe_20250331',rqdatac.index_components,order_book_id='000905.XSHG',date='2025-03-31')
probe('members_probe_20251231',rqdatac.index_components,order_book_id='000905.XSHG',date='2025-12-31')
probe('price_overlap_post',rqdatac.get_price,order_book_ids=['000005.XSHE','600004.XSHG'],
      start_date='2022-12-01',end_date='2023-02-01',frequency='1d',fields=['close','volume','total_turnover'],
      adjust_type='post',skip_suspended=False)
probe('turnover_probe',rqdatac.get_turnover_rate,order_book_ids=['000005.XSHE','600004.XSHG'],
      start_date='2022-12-01',end_date='2022-12-30',fields=['today'])
probe('shibor_probe',rqdatac.get_interbank_offered_rate,
      start_date='2026-01-01',end_date='2026-02-02',fields=['ON','1M'])
status['signatures']={n:str(inspect.signature(getattr(rqdatac,n))) for n in
    ['get_price','get_factor','get_pit_financials_ex','index_components','get_interbank_offered_rate']}
(OUT/'probe_manifest.json').write_text(json.dumps(status,ensure_ascii=False,indent=2,default=str))
print('Probe manifest saved',flush=True)
