"""Inventory every original file, inspect ZIPs safely, and audit PKLs one by one."""
from pathlib import Path, PurePosixPath
import json
import gc
import hashlib
import zipfile
import stat
import numpy as np
import pandas as pd
from common import source_path, ROOT, AUDIT, load_local, sha256, md_table

AUDIT.mkdir(parents=True, exist_ok=True)
GENERATED = {'.venv', '.git', 'scripts', 'reports', 'results', 'data', 'notebooks', 'tmp', '__pycache__'}
files = sorted(p for p in ROOT.rglob('*') if p.is_file()
               and not set(p.relative_to(ROOT).parts).intersection(GENERATED)
               and p.name != '.DS_Store')
baseline=AUDIT/'original_file_manifest.csv'
if baseline.exists():
    # Preserve the first source inventory. Newly generated README/configuration
    # files are not silently relabeled as original user data on reproduction.
    original=pd.read_csv(baseline)
    files=[source_path(name) for name in original.path]
manifest = pd.DataFrame([dict(path=str(p.relative_to(ROOT)), bytes=p.stat().st_size,
                             mtime_ns=p.stat().st_mtime_ns, sha256=sha256(p)) for p in files])
if baseline.exists():
    assert manifest.sha256.tolist()==original.sha256.tolist(), 'An original source file changed.'
else:
    manifest.to_csv(baseline, index=False)
by_hash = manifest.groupby('sha256')['path'].agg(list).to_dict()
zip_rows = []
for path in files:
    if path.suffix != '.zip':
        continue
    with zipfile.ZipFile(path) as z:
        for member in z.infolist():
            raw_name = member.filename
            # macOS ZIPs sometimes store UTF-8 bytes under the legacy CP437 flag.
            name = raw_name
            if not member.flag_bits & 0x800:
                try:
                    name = raw_name.encode('cp437').decode('utf-8')
                except UnicodeError:
                    pass
            parts = PurePosixPath(name).parts
            safe = (not PurePosixPath(name).is_absolute() and '..' not in parts
                    and '\\' not in name and not stat.S_ISLNK(member.external_attr >> 16))
            row = dict(archive=path.name, member=name, bytes=member.file_size,
                       compressed_bytes=member.compress_size, safe_path=safe,
                       sha256='', identical_existing='', extracted_to='')
            if member.is_dir() or '__MACOSX' in parts or Path(name).name.startswith('._'):
                zip_rows.append(row)
                continue
            if not safe:
                raise ValueError(f'Unsafe ZIP member: {name}')
            with z.open(member) as source:
                digest = hashlib.file_digest(source, 'sha256').hexdigest()
            row['sha256'] = digest
            duplicates = by_hash.get(digest, [])
            row['identical_existing'] = '; '.join(duplicates)
            # Only extract new data and dictionaries; preserve ZIPs and originals.
            if not duplicates and Path(name).suffix.lower() in {'.csv', '.txt'}:
                base = ROOT / 'data/raw/csmar' / path.stem
                destination = (base / name).resolve()
                if not destination.is_relative_to(base.resolve()):
                    raise ValueError(name)
                destination.parent.mkdir(parents=True, exist_ok=True)
                if not destination.exists():
                    with z.open(member) as source, destination.open('wb') as out:
                        while chunk := source.read(1024 * 1024):
                            out.write(chunk)
                assert sha256(destination) == digest
                row['extracted_to'] = str(destination.relative_to(ROOT))
            zip_rows.append(row)
pd.DataFrame(zip_rows).to_csv(AUDIT / 'zip_members.csv', index=False)

summaries, details = [], {}
for path in files:
    if path.suffix != '.pkl':
        continue
    print('Auditing', path.name, flush=True)
    obj = load_local(path.name)
    df = obj.to_frame() if isinstance(obj, pd.Series) else obj
    if not isinstance(df, pd.DataFrame):
        raise ValueError(f'Unexpected object type: {path.name}, {type(obj)}')
    dates = df.index if isinstance(df.index, pd.DatetimeIndex) else None
    values = df.to_numpy()
    numeric = all(pd.api.types.is_numeric_dtype(t) for t in df.dtypes)
    missing = int(df.isna().sum().sum())
    frequency = 'non-date/static'
    if dates is not None:
        gap = float(pd.Series(dates).diff().dt.days.median())
        frequency = 'daily trading calendar' if gap <= 3 else ('monthly' if gap <= 35 else 'annual/other')
    stock_count = len(df.columns) if dates is not None else len(df.index)
    row = dict(filename=path.name, object_type=type(obj).__name__, rows=df.shape[0],
               columns=df.shape[1], index_type=type(df.index).__name__,
               column_type=type(df.columns).__name__, index_name=str(df.index.name),
               columns_name=str(df.columns.name),
               date_start=str(dates.min().date()) if dates is not None else '',
               date_end=str(dates.max().date()) if dates is not None else '',
               stocks=stock_count, frequency=frequency, missing_cells=missing,
               missing_share=missing/df.size, duplicate_index=int(df.index.duplicated().sum()),
               duplicate_columns=int(df.columns.duplicated().sum()),
               duplicate_rows=int(df.duplicated().sum()),
               memory_MiB=float(df.memory_usage(index=True, deep=True).sum()/2**20),
               dtypes=';'.join(map(str, df.dtypes.unique())),
               attrs=json.dumps(obj.attrs, default=str, ensure_ascii=False))
    detail = dict(column_examples=list(map(str, df.columns[:12])),
                  index_examples=list(map(str, df.index[:5])), summary=row)
    if numeric:
        arr = values.astype(float, copy=False)
        finite = arr[np.isfinite(arr)]
        detail['finite_quantiles'] = dict(zip(['min','p01','median','p99','max'],
                                             np.quantile(finite,[0,.01,.5,.99,1]).tolist())) if finite.size else {}
        detail['infinite_cells'] = int(np.isinf(arr).sum())
        detail['all_missing_rows'] = int(df.isna().all(axis=1).sum())
        detail['all_missing_columns'] = int(df.isna().all(axis=0).sum())
        if finite.size and len(np.unique(finite[:10000])) < 30:
            detail['value_counts'] = {str(k):int(v) for k,v in pd.Series(finite).value_counts().items()}
        del arr, finite
    if dates is not None and len(df.columns)>100 and ('flag' in path.name or 'components' in path.name or 'mask' in path.name):
        detail['row_true_counts'] = df.eq(True).sum(axis=1).describe().to_dict()
    summaries.append(row)
    details[path.name] = detail
    del obj, df, values
    gc.collect()
pd.DataFrame(summaries).to_csv(AUDIT / 'pkl_inventory.csv', index=False)
(AUDIT / 'pkl_details.json').write_text(json.dumps(details, ensure_ascii=False, indent=2))

csv_rows, csv_details = [], {}
csv_files = [p for p in files if p.suffix=='.csv'] + list((ROOT/'data/raw/csmar').rglob('*.csv'))
for path in csv_files:
    d = pd.read_csv(path, dtype={'Stkcd':'string','stock':'string','code':'string'}, low_memory=False)
    name = str(path.relative_to(ROOT))
    date_cols = [c for c in d if c in ['Accper','Annodt','Trddt','TradingDate','Clsdt',
                                      'formation_date','entry_date','exit_date','source_update_date','TradingDate']]
    ranges = {c:dict(start=str(d[c].min()),end=str(d[c].max()),missing=int(d[c].isna().sum()))
              for c in date_cols}
    key = [c for c in ['Stkcd','Trddt'] if c in d]
    if 'Accper' in d:
        key = [c for c in ['Stkcd','Accper','Typrep','Source','Reptyp'] if c in d]
    if 'formation_date' in d:
        key = ['formation_date','stock']
    if 'Clsdt' in d:
        key = ['Nrr1','Clsdt']
    row = dict(filename=name, rows=len(d), columns=len(d.columns),
               stocks=int(d['Stkcd'].nunique()) if 'Stkcd' in d else (int(d.stock.nunique()) if 'stock' in d else ''),
               missing_cells=int(d.isna().sum().sum()), duplicate_rows=int(d.duplicated().sum()),
               candidate_key=','.join(key), duplicate_keys=int(d.duplicated(key).sum()) if key else '',
               memory_MiB=float(d.memory_usage(deep=True).sum()/2**20), date_ranges=json.dumps(ranges))
    csv_rows.append(row)
    csv_details[name]=dict(columns=list(d.columns), dates=ranges, missing=d.isna().sum().to_dict(),
                           first_rows=d.head(2).astype(str).to_dict('records'))
    del d
    gc.collect()
pd.DataFrame(csv_rows).to_csv(AUDIT/'csv_inventory.csv',index=False)
(AUDIT/'csv_details.json').write_text(json.dumps(csv_details,ensure_ascii=False,indent=2))
summary = dict(original_files=len(files), total_original_bytes=int(manifest.bytes.sum()),
               pkl_files=len(summaries), zip_files=sum(p.suffix=='.zip' for p in files),
               csv_files_inspected=len(csv_rows),
               duplicate_file_groups=[v for v in by_hash.values() if len(v)>1])
(AUDIT/'audit_summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2))
print(json.dumps(summary,ensure_ascii=False,indent=2))
