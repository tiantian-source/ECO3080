"""Small shared helpers. Original project data are always read-only."""
from pathlib import Path
import importlib
import pickle
import hashlib
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
AUDIT = ROOT / 'reports/audit'

LOCAL_ROOT = ROOT / 'data/raw/local'
def source_path(name):
    """Locate original source or historical snapshot after the directory migration."""
    import json
    key=str(name)
    ledger=ROOT/'reports/organization/path_map.json'
    mapping=json.loads(ledger.read_text()) if ledger.exists() else {}
    return (ROOT/mapping.get(key,key)).resolve()

def verify_historical(path, expected_sha256):
    """Check unchanged content, or explicitly recorded path-only source amendments."""
    import json
    path=Path(path);actual=sha256(path)
    if actual==expected_sha256:return True
    ledger=ROOT/'reports/organization/code_path_changes.json'
    if not ledger.exists():return False
    try:key=str(path.relative_to(ROOT))
    except ValueError:return False
    item=json.loads(ledger.read_text()).get(key,{})
    return item.get('before_sha256')==expected_sha256 and item.get('after_sha256')==actual


# Only the user-supplied local pandas/NumPy data files are accepted. No arbitrary
# Python globals, extension opcodes, external persistent objects or code loaders.
ALLOWED = {
    ('pandas.core.frame', 'DataFrame'), ('pandas.core.series', 'Series'),
    ('pandas.core.internals.managers', 'BlockManager'),
    ('pandas.core.internals.managers', 'SingleBlockManager'),
    ('pandas._libs.internals', '_unpickle_block'),
    ('numpy.core.numeric', '_frombuffer'), ('numpy._core.numeric', '_frombuffer'),
    ('numpy', 'dtype'), ('numpy', 'ndarray'),
    ('numpy.core.multiarray', '_reconstruct'),
    ('numpy._core.multiarray', '_reconstruct'), ('builtins', 'slice'),
    ('pandas.core.indexes.base', '_new_Index'),
    ('pandas.core.indexes.base', 'Index'),
    ('pandas.core.indexes.datetimes', '_new_DatetimeIndex'),
    ('pandas.core.indexes.datetimes', 'DatetimeIndex'),
    ('pandas._libs.arrays', '__pyx_unpickle_NDArrayBacked'),
    ('pandas.core.arrays.datetimes', 'DatetimeArray'),
    ('pandas._libs.tslibs.offsets', 'MonthEnd'),
    ('pandas._libs.tslibs.offsets', 'YearEnd'),
    ('pandas.core.indexes.range', 'RangeIndex'),
}

class ProjectDataUnpickler(pickle.Unpickler):
    def find_class(self, module, name):
        if (module, name) not in ALLOWED:
            raise pickle.UnpicklingError(f'Unapproved pickle global: {module}.{name}')
        if module.startswith('numpy.core.'):
            module = module.replace('numpy.core.', 'numpy._core.')
        return getattr(importlib.import_module(module), name)

    def persistent_load(self, pid):
        raise pickle.UnpicklingError('External persistent data are not allowed')

def load_local(name):
    path = source_path(name)
    if Path(name).name != name or path.parent != LOCAL_ROOT or path.suffix != '.pkl':
        raise ValueError('Only mapped original local PKL files may be loaded')
    with path.open('rb') as stream:
        obj = ProjectDataUnpickler(stream).load()
        if stream.read(1):
            raise ValueError(f'Trailing content: {name}')
    return obj

def sha256(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def md_table(df):
    # Avoid an extra table dependency and keep Markdown tables compact.
    df = df.copy().fillna('')
    lines = ['| ' + ' | '.join(map(str, df.columns)) + ' |',
             '| ' + ' | '.join(['---'] * len(df.columns)) + ' |']
    for row in df.itertuples(index=False, name=None):
        lines.append('| ' + ' | '.join(str(v).replace('|', '/') for v in row) + ' |')
    return '\n'.join(lines)
