"""Final empirical checks, original-file integrity, optional notebook execution."""
import os
import sys
import json
from pathlib import Path
from datetime import datetime
import numpy as np
import pandas as pd
from scipy.stats import t as student_t
from common import source_path, ROOT,AUDIT,sha256

def main():
    panel=pd.read_parquet(ROOT/'data/processed/panel_monthly.parquet')
    predictions=pd.read_parquet(ROOT/'results/predictions/oos_predictions.parquet')
    config=json.loads((ROOT/'research_config.json').read_text())
    run=json.loads((ROOT/'results/model_run_manifest.json').read_text())
    checks={}
    checks['panel_unique']=not panel.duplicated(['formation_month','stock']).any()
    checks['historical_500_each_month']=bool(panel.groupby('formation_month').size().eq(500).all())
    checks['date_order']=bool((panel.formation_date<panel.entry_date).all() and (panel.entry_date<panel.exit_date).all())
    checks['feature_cutoff']=bool(panel.feature_information_cutoff.le(panel.formation_date).all())
    checks['PIT_eligible']=bool(panel.loc[panel.eligible_at_formation,'pit_financial_verified'].all())
    checks['eight_features']=len(config['features'])==8 and run['features']==config['features']
    checks['common_oos_keys']=not predictions.duplicated(['holding_month','stock']).any()
    checks['36_test_months']=predictions.holding_month.nunique()==36
    checks['same_test_predictions']=bool(predictions[[m+'_pred' for m in ['OLS','LASSO','RF','MLP']]].notna().all().all())
    checks['no_future_training_labels']=bool(predictions.training_last_label_available_date.le(predictions.model_estimation_date).all())
    checks['estimation_before_prediction']=bool(predictions.model_estimation_date.le(predictions.prediction_date).all())
    checks['config_not_changed']=sha256(ROOT/'research_config.json')==run['config_sha256']
    checks['panel_not_changed']=sha256(ROOT/'data/processed/panel_monthly.parquet')==run['panel_sha256']
    checks['model_code_not_changed']=sha256(ROOT/'scripts/05_models.py')==run['script_sha256']
    eligible_test=panel.loc[panel.eligible_at_formation&panel.holding_month.between('2023-01','2025-12'),['holding_month','stock']]
    checks['exante_pool_not_filtered_on_Y']=set(map(tuple,eligible_test.to_numpy()))==set(map(tuple,predictions[['holding_month','stock']].to_numpy()))
    folds=pd.read_csv(ROOT/'results/tables/validation_folds.csv')
    checks['24_validation_prediction_months']=folds.holding_month.nunique()==24
    checks['23_known_validation_months_at_freeze']=folds.loc[folds.available_for_selection].holding_month.nunique()==23
    checks['December2022_excluded_from_selection']=not bool(folds.loc[folds.holding_month.eq('2022-12'),'available_for_selection'].any())
    weights=pd.read_parquet(ROOT/'results/predictions/portfolio_weights.parquet')
    checks['weights_sum_one']=bool(np.allclose(weights.groupby(['holding_month','model','portfolio']).weight.sum(),1))
    checks['portfolio_uses_raw_return']=bool(np.allclose(
        (weights.weight*weights.raw_return).groupby([weights.holding_month,weights.model,weights.portfolio]).sum().sort_index(),
        pd.read_csv(ROOT/'results/tables/decile_returns.csv').set_index(['holding_month','model','portfolio']).raw_return.sort_index()))
    # Independent HAC formula audit, rather than reusing statsmodels internals.
    nw=pd.read_csv(ROOT/'results/tables/forecast_comparison.csv').set_index('model')
    manual=[]
    for model in ['LASSO','RF','MLP']:
        diff=((predictions.actual_excess_return-predictions.OLS_pred)**2-(predictions.actual_excess_return-predictions[model+'_pred'])**2).groupby(predictions.holding_month).mean().to_numpy()
        n=len(diff);u=diff-diff.mean();v=np.dot(u,u)/n
        for lag in range(1,4):
            v+=2*(1-lag/4)*np.dot(u[lag:],u[:-lag])/n
        se=np.sqrt(v/n*n/(n-1));stat=diff.mean()/se;p=2*student_t.sf(abs(stat),n-1)
        assert np.isclose(se,nw.loc[model,'nw_standard_error'])
        assert np.isclose(p,nw.loc[model,'p_value'])
        manual.append(dict(model=model,manual_nw_se=se,manual_t=stat,manual_p=p))
    pd.DataFrame(manual).to_csv(AUDIT/'independent_hac_check.csv',index=False)
    checks['independent_HAC_SE_and_p']=True
    application=pd.read_parquet(ROOT/'results/predictions/application_2026_01.parquet')
    checks['application_last_label_November2025']=bool(application.training_sample_end.eq('2025-11').all())
    checks['application_independent_of_test']=not bool(predictions.holding_month.eq('2026-01').any())
    checks['application_no_future_label']=bool(application.training_last_label_available_date.le(application.model_estimation_date).all())
    original=pd.read_csv(AUDIT/'original_file_manifest.csv')
    checks['all_original_bytes_unchanged']=all(sha256(source_path(row.path))==row.sha256 for row in original.itertuples())
    checks['all_original_mtimes_unchanged']=all(source_path(row.path).stat().st_mtime_ns==row.mtime_ns for row in original.itertuples())
    required=['reports/01_data_audit.md','reports/02_rqdata_completion.md','reports/03_data_readiness.md',
              'reports/04_panel_validation.md','reports/research_results_summary.md','reports/paper_outline.md',
              'results/tables/model_performance.csv','results/tables/forecast_comparison.csv',
              'results/tables/portfolio_performance.csv','results/tables/decile_returns.csv',
              'results/tables/feature_importance.csv','results/tables/application_d10_holdings.csv']
    checks['required_artifacts_exist']=all((ROOT/p).is_file() and (ROOT/p).stat().st_size>0 for p in required)
    assert all(checks.values()),{k:v for k,v in checks.items() if not v}
    notebook_results=[]
    if '--execute-notebooks' in sys.argv:
        import nbformat
        from nbclient import NotebookClient
        os.environ['JUPYTER_PATH']=str(ROOT/'tmp/jupyter')
        os.environ['JUPYTER_RUNTIME_DIR']=str(ROOT/'tmp/jupyter_runtime')
        (ROOT/'tmp/jupyter_runtime').mkdir(parents=True,exist_ok=True)
        for path in sorted((ROOT/'notebooks').glob('*.ipynb')):
            print('Executing notebook',path.name,flush=True)
            notebook=nbformat.read(path,as_version=4)
            NotebookClient(notebook,timeout=180,kernel_name='eco3080-quant',
                           resources={'metadata':{'path':str(ROOT)}}).execute()
            nbformat.write(notebook,path)
            errors=[out for cell in notebook.cells if cell.cell_type=='code' for out in cell.outputs if out.output_type=='error']
            assert not errors
            notebook_results.append(dict(notebook=path.name,status='EXECUTED_WITHOUT_ERRORS'))
    else:
        import nbformat
        for path in sorted((ROOT/'notebooks').glob('*.ipynb')):
            notebook=nbformat.read(path,as_version=4)
            code=[cell for cell in notebook.cells if cell.cell_type=='code']
            executed=all(cell.execution_count is not None for cell in code)
            errors=[out for cell in code for out in cell.outputs if out.output_type=='error']
            if executed and not errors:
                notebook_results.append(dict(notebook=path.name,status='EXECUTED_WITHOUT_ERRORS'))
    checks['seven_notebooks_executed']=len(notebook_results)==7
    review=dict(status='PASSED',checks=checks,notebooks=notebook_results,
                results_are_theoretical_portfolios=True,original_files_checked=len(original),
                no_unresolved_critical_financial_PIT_gate=True,
                limitations=json.loads((ROOT/'data/processed/data_status.json').read_text())['limitations'])
    (R:=ROOT/'reports/final_quality_review.json').write_text(json.dumps(review,indent=2,ensure_ascii=False))
    csv=pd.DataFrame([dict(check=k,passed=v) for k,v in checks.items()])
    csv.to_csv(AUDIT/'final_quality_checks.csv',index=False)
    print(json.dumps(review,ensure_ascii=False,indent=2),flush=True)

if __name__=='__main__':
    main()
