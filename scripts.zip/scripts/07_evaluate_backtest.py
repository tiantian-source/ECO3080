"""Evaluate saved predictions only: no refitting or retuning in this script."""
import os
os.environ.setdefault('MPLCONFIGDIR',str(__import__('pathlib').Path(__file__).resolve().parents[1]/'tmp/matplotlib'))
import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from common import ROOT

CONFIG=json.loads((ROOT/'research_config.json').read_text())
MODELS=['OLS','LASSO','RF','MLP']
T=ROOT/'results/tables';F=ROOT/'results/figures';P=ROOT/'results/predictions'
F.mkdir(parents=True,exist_ok=True)
plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False,
                     'figure.dpi':130,'savefig.dpi':250,'axes.grid':True,'grid.alpha':.18})

def prediction_metrics(data):
    d=data.dropna(subset=['actual_excess_return'])
    assert d[[m+'_pred' for m in MODELS]].notna().all().all()
    y=d.actual_excess_return.to_numpy()
    return pd.DataFrame([dict(model=m,observations=len(d),months=d.holding_month.nunique(),
        oos_r2=1-np.sum((y-d[m+'_pred'].to_numpy())**2)/np.sum(y**2),
        rmse=np.sqrt(np.mean((y-d[m+'_pred'].to_numpy())**2)),
        mae=np.mean(np.abs(y-d[m+'_pred'].to_numpy()))) for m in MODELS])

def strict_weighted_return(g,weights):
    # Do not drop a future missing return or renormalize selected survivors.
    if g.actual_raw_return.isna().any():
        return np.nan
    return float(np.dot(weights,g.actual_raw_return))

def portfolio_metrics(returns,rf,turnover,spread=False):
    assert returns.notna().all()
    excess=returns if spread else returns-rf
    wealth=np.r_[1.,np.cumprod(1+returns.to_numpy())]
    return dict(months=len(returns),cumulative_return=wealth[-1]-1,
        annualized_return=wealth[-1]**(12/len(returns))-1,
        annualized_volatility=returns.std(ddof=1)*np.sqrt(12),
        sharpe=excess.mean()/excess.std(ddof=1)*np.sqrt(12),
        maximum_drawdown=float(np.min(wealth/np.maximum.accumulate(wealth)-1)),
        mean_one_way_turnover=float(turnover.iloc[1:].mean()) if len(turnover)>1 else np.nan)

def construct_portfolios(data):
    records=[];weights_records=[];diagnostics=[]
    # All predictions are available BEFORE looking at realized returns.
    for month,g in data.groupby('holding_month',sort=True):
        for name in MODELS+['EW','VW']:
            if name in MODELS:
                ranked=g.sort_values([name+'_pred','stock'],kind='stable').copy()
                ranked['decile']=np.arange(len(ranked))*10//len(ranked)+1
                assert ranked.decile.nunique()==10
                groups=[(f'D{int(decile)}',sub,np.repeat(1/len(sub),len(sub)))
                        for decile,sub in ranked.groupby('decile',sort=True)]
            else:
                weights=np.repeat(1/len(g),len(g)) if name=='EW' else g.market_cap.to_numpy()/g.market_cap.sum()
                groups=[('ALL',g,weights)]
            for portfolio,sub,w in groups:
                raw=strict_weighted_return(sub,w)
                records.append(dict(holding_month=month,model=name,portfolio=portfolio,raw_return=raw,
                    rf_return=sub.rf_return.iloc[0],rf_shibor=sub.rf_shibor_1m_entry_proxy.iloc[0],stocks=len(sub)))
                for row,weight in zip(sub.itertuples(),w):
                    # Stable identity across the documented 300114 code change.
                    identity='302132.SZ' if row.stock=='300114.SZ' else row.stock
                    weights_records.append(dict(holding_month=month,model=name,portfolio=portfolio,
                       stock=row.stock,security_id=identity,weight=float(weight),raw_return=row.actual_raw_return))
                if portfolio in ['D1','D10','ALL']:
                    diagnostics.append(dict(holding_month=month,model=name,portfolio=portfolio,stocks=len(sub),
                        entry_suspended=int(sub.entry_suspend.eq(1).sum()),
                        entry_limit_up=int(sub.entry_limit_up.eq(1).sum()),
                        entry_unknown_state=int(sub[['entry_suspend','entry_limit_up']].isna().any(axis=1).sum()),
                        exit_suspended=int(sub.exit_suspend.eq(1).sum()),
                        exit_limit_down=int(sub.exit_limit_down.eq(1).sum()),
                        exit_unknown_state=int(sub[['exit_suspend','exit_limit_down']].isna().any(axis=1).sum()),
                        missing_return=int(sub.actual_raw_return.isna().sum())))
    returns=pd.DataFrame(records);weights=pd.DataFrame(weights_records)
    turnover_rows=[]
    for (name,portfolio),all_weights in weights.groupby(['model','portfolio']):
        previous=None;previous_return=None
        for month,g in all_weights.groupby('holding_month',sort=True):
            target=g.set_index('security_id').weight
            assert not target.index.duplicated().any()
            if previous is None:
                drift=pd.Series(dtype=float);cash_change=1.
            else:
                drift=previous.weight*(1+previous.raw_return)/(1+previous_return)
                cash_change=0.
            union=target.index.union(drift.index)
            traded=float((target.reindex(union,fill_value=0)-drift.reindex(union,fill_value=0)).abs().sum())
            turnover_rows.append(dict(holding_month=month,model=name,portfolio=portfolio,
                traded_stock_notional=traded,one_way_turnover=.5*(traded+cash_change)))
            previous=g.set_index('security_id')[['weight','raw_return']]
            previous_return=float(np.sum(previous.weight*previous.raw_return))
    returns=returns.merge(pd.DataFrame(turnover_rows),on=['holding_month','model','portfolio'],validate='one_to_one')
    return returns,weights,pd.DataFrame(diagnostics)

def main():
    oos=pd.read_parquet(P/'oos_predictions.parquet')
    assert oos.holding_month.nunique()==36
    assert not oos.duplicated(['holding_month','stock']).any()
    prediction_metrics(oos).to_csv(T/'model_performance.csv',index=False)
    evaluable=oos.dropna(subset=['actual_excess_return'])
    loss_rows=[];monthly_losses=[]
    for name in ['LASSO','RF','MLP']:
        error_difference=(evaluable.actual_excess_return-evaluable.OLS_pred)**2-(evaluable.actual_excess_return-evaluable[name+'_pred'])**2
        monthly=error_difference.groupby(evaluable.holding_month).mean()
        assert len(monthly)==36
        fit=sm.OLS(monthly.to_numpy(),np.ones((36,1))).fit(cov_type='HAC',use_t=True,
            cov_kwds={'maxlags':CONFIG['hac_lag'],'kernel':'bartlett','use_correction':True})
        loss_rows.append(dict(model=name,reference='OLS',mean_mse_improvement=monthly.mean(),
            nw_standard_error=float(fit.bse[0]),nw_t_stat=float(fit.tvalues[0]),p_value=float(fit.pvalues[0]),
            months=36,hac_lag=3,df=35))
        monthly_losses.extend([dict(holding_month=m,model=name,ols_mse_minus_model_mse=v) for m,v in monthly.items()])
    pd.DataFrame(loss_rows).to_csv(T/'forecast_comparison.csv',index=False)
    pd.DataFrame(monthly_losses).to_csv(T/'monthly_forecast_loss_differences.csv',index=False)

    returns,weights,diagnostics=construct_portfolios(oos)
    assert returns.raw_return.notna().all()
    returns.to_csv(T/'decile_returns.csv',index=False)
    weights.to_parquet(P/'portfolio_weights.parquet',index=False)
    diagnostics.to_csv(T/'trading_feasibility.csv',index=False)
    metrics=[];curves={};ls_curves={};cost_rows=[]
    for name in MODELS+['EW','VW']:
        label='D10' if name in MODELS else 'ALL'
        r=returns.loc[returns.model.eq(name)&returns.portfolio.eq(label)].set_index('holding_month').sort_index()
        stats=portfolio_metrics(r.raw_return,r.rf_return,r.one_way_turnover)
        stats.update(model=name,portfolio=label,sharpe_shibor_1m=(r.raw_return-r.rf_shibor).mean()/(r.raw_return-r.rf_shibor).std(ddof=1)*np.sqrt(12))
        metrics.append(stats);curves[name]=r.raw_return
        for bps in CONFIG['transaction_cost_bps_per_traded_notional']:
            net=(1-bps/10000*r.traded_stock_notional)*(1+r.raw_return)-1
            c=portfolio_metrics(net,r.rf_return,r.one_way_turnover)
            cost_rows.append(dict(model=name,portfolio=label,assumed_cost_bps=bps,**c))
        if name in MODELS:
            by_decile=returns.loc[returns.model.eq(name)].pivot(index='holding_month',columns='portfolio',values='raw_return').sort_index()
            spread=by_decile.D10-by_decile.D1
            # Long and short legs each have unit notional; this is a synthetic
            # normalized spread and excludes borrowing/margin costs.
            d1=returns.loc[returns.model.eq(name)&returns.portfolio.eq('D1')].set_index('holding_month').sort_index()
            gross_turnover=r.one_way_turnover+d1.one_way_turnover
            ls=portfolio_metrics(spread,r.rf_return,gross_turnover,spread=True)
            metrics.append(dict(model=name,portfolio='D10-D1 theoretical',**ls))
            ls_curves[name]=spread
    pd.DataFrame(metrics).to_csv(T/'portfolio_performance.csv',index=False)
    pd.DataFrame(cost_rows).to_csv(T/'transaction_cost_sensitivity.csv',index=False)
    deciles=returns.loc[returns.model.isin(MODELS)].groupby(['model','portfolio']).agg(
        mean_monthly_return=('raw_return','mean'),monthly_volatility=('raw_return','std'),
        months=('holding_month','nunique')).reset_index()
    deciles.to_csv(T/'decile_return_summary.csv',index=False)
    ties=oos.groupby('holding_month')[[m+'_pred' for m in MODELS]].nunique()
    ties.to_csv(T/'prediction_tie_diagnostics.csv')

    # The wealth path explicitly starts at 1, including the first-month loss in MDD.
    def plot_wealth(series,title,filename,ylabel='Wealth (initial = 1)'):
        fig,ax=plt.subplots(figsize=(9,4.7))
        dates=pd.period_range('2023-01','2025-12',freq='M').to_timestamp('M')
        for name,r in series.items():
            wealth=np.r_[1.,(1+r).cumprod().to_numpy()]
            ax.plot(pd.DatetimeIndex([pd.Timestamp('2022-12-31')]).append(dates),wealth,
                    label=name,linewidth=1.7,linestyle='--' if name in ['EW','VW'] else '-')
        ax.set(title=title,ylabel=ylabel,xlabel='Holding month')
        tick_months=['2023-01','2023-07','2024-01','2024-07','2025-01','2025-07','2025-12']
        ax.set_xticks(pd.PeriodIndex(tick_months,freq='M').to_timestamp('M'),tick_months)
        ax.set_xlim(pd.Timestamp('2022-12-31'),pd.Timestamp('2025-12-31'))
        ax.legend(ncol=3,frameon=False);fig.tight_layout()
        fig.savefig(F/filename);plt.close(fig)
    plot_wealth(curves,'D10 and eligible-universe benchmarks: theoretical, before costs','cumulative_d10.png')
    plot_wealth(ls_curves,'D10 minus D1: synthetic theoretical spread','cumulative_long_short.png')
    fig,ax=plt.subplots(figsize=(9,4.5))
    for name in MODELS:
        r=returns.loc[returns.model.eq(name)].groupby('portfolio').raw_return.mean()
        ax.plot(range(1,11),[100*r[f'D{i}'] for i in range(1,11)],marker='o',label=name)
    ax.set(xlabel='Forecast decile (D10 = highest)',ylabel='Mean monthly raw return (%)',
           title='Realized returns of forecast-sorted deciles',xticks=range(1,11))
    ax.legend(frameon=False);fig.tight_layout();fig.savefig(F/'decile_performance.png');plt.close(fig)
    performance=prediction_metrics(oos)
    fig,ax=plt.subplots(figsize=(7,4))
    ax.bar(performance.model,100*performance.oos_r2,color=['#555555','#377eb8','#4daf4a','#984ea3'])
    ax.axhline(0,color='black',linewidth=.8)
    ax.set(ylabel='OOS R² (%)',title='2023–2025 excess-return prediction; zero forecast benchmark')
    fig.tight_layout();fig.savefig(F/'prediction_performance.png');plt.close(fig)
    importance=pd.read_csv(T/'permutation_importance_monthly.csv')
    imp=importance.groupby(['model','feature']).mse_increase.agg(['mean','std']).reset_index()
    imp.to_csv(T/'feature_importance.csv',index=False)
    fig,axes=plt.subplots(1,2,figsize=(10,4.6),sharex=False)
    for ax,name in zip(axes,['RF','MLP']):
        sub=imp.loc[imp.model.eq(name)].sort_values('mean')
        ax.barh(sub.feature,sub['mean']*10000,color='#377eb8' if name=='RF' else '#984ea3')
        ax.axvline(0,color='black',linewidth=.7);ax.set(title=name,xlabel='Increase in monthly MSE (×10⁴)')
    fig.suptitle('Within-month OOS permutation importance; descriptive, not causal')
    fig.tight_layout();fig.savefig(F/'feature_importance.png');plt.close(fig)

    app=pd.read_parquet(P/'application_2026_01.parquet')
    prediction_metrics(app).to_csv(T/'application_prediction_metrics.csv',index=False)
    app_returns,app_weights,app_feasibility=construct_portfolios(app)
    app_returns.to_csv(T/'application_decile_returns.csv',index=False)
    app_weights.loc[app_weights.portfolio.eq('D10')].to_csv(T/'application_d10_holdings.csv',index=False)
    app_feasibility.to_csv(T/'application_trading_feasibility.csv',index=False)
    app_returns.loc[app_returns.portfolio.isin(['D10','ALL'])].to_csv(T/'application_portfolio.csv',index=False)
    print('Prediction evaluation, HAC, portfolios, cost sensitivity, figures and application completed.')
    print(performance.to_string(index=False))
    print(pd.DataFrame(metrics).to_string(index=False))

if __name__=='__main__':
    main()
