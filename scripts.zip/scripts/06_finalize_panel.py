"""Verify source overlaps/PIT and open the formal eight-predictor data gate."""
import json
import numpy as np
import pandas as pd
from common import ROOT,AUDIT,load_local,sha256,md_table

RAW=ROOT/'data/raw/rqdata'
panel=pd.read_parquet(ROOT/'data/processed/panel_monthly.parquet')
assert panel.membership_source.str.startswith('RQData').all()
checks=[];frames=[]
mapping={'book_to_market_ratio_ttm':'bm','ep_ratio_ttm':'ep','return_on_asset_net_profit_ttm':'roa'}
for path in sorted(RAW.glob('financial_20*.parquet')):
    d=pd.read_parquet(path).reset_index()
    d['formation_month']=path.stem[-7:]
    d['stock']=d.order_book_id.str.replace('.XSHG','.SH',regex=False).str.replace('.XSHE','.SZ',regex=False)
    d=d.rename(columns={k:v+'_raw' for k,v in mapping.items()})
    frames.append(d)
financial=pd.concat(frames,ignore_index=True)
assert financial.formation_month.nunique()==193
assert not financial.duplicated(['formation_month','stock']).any()
panel=panel.merge(financial[['formation_month','stock','date','bm_raw','ep_raw','roa_raw','a_share_market_val_3','market_cap_3']],
                  how='left',on=['formation_month','stock'],validate='one_to_one')
assert (panel.date.dropna()<=panel.loc[panel.date.notna(),'formation_date']).all()
for factor in ['bm','ep','roa']:
    a=panel[f'{factor}_raw'];b=panel[f'{factor}_unverified']
    good=a.notna()&b.notna()
    checks.append(dict(variable=factor,overlap=int(good.sum()),max_abs_difference=float((a[good]-b[good]).abs().max()),
                       differing_gt1e_8=int(((a[good]-b[good]).abs()>1e-8).sum()),
                       source='Use newly cached RQData PIT values throughout; original values retained'))
good=panel.market_cap.notna()&panel.a_share_market_val_3.notna()
checks.append(dict(variable='A share market value',overlap=int(good.sum()),
    max_abs_difference=float((panel.loc[good,'market_cap']-panel.loc[good,'a_share_market_val_3']).abs().max()),
    differing_gt1e_8=int((~np.isclose(panel.loc[good,'market_cap'],panel.loc[good,'a_share_market_val_3'],rtol=1e-10)).sum()),
    source='Local A-share capitalization checked against explicitly named RQData field'))
pd.DataFrame(checks).to_csv(AUDIT/'rqdata_factor_crosscheck.csv',index=False)
# Size stays the documented A-share market value specified by the existing
# research source, not silently changed to free-float or total-company market cap.
assert np.allclose(panel.loc[good,'market_cap'],panel.loc[good,'a_share_market_val_3'],rtol=1e-8)

pit_checks=[]
for path in sorted(RAW.glob('pit_asof_*.parquet')):
    date=pd.Timestamp(path.stem[-10:])
    d=pd.read_parquet(path).reset_index()
    assert pd.to_datetime(d.info_date).le(date).all()
    inputs=pd.read_parquet(RAW/f'factor_inputs_{date.date()}.parquet').reset_index().set_index('order_book_id')
    for stock,g in d.groupby('order_book_id'):
        g=g.sort_values('info_date',kind='stable').drop_duplicates('quarter',keep='last').set_index('quarter')
        g.index=pd.PeriodIndex(g.index,freq='Q')
        q=g.index.max()
        # Financial income fields are cumulative year-to-date in original reports.
        # TTM = current YTD + prior annual - prior same YTD (annual is direct).
        reconstructed={}
        for field in ['net_profit','net_profit_parent_company']:
            reconstructed[field+'_ttm_0']=g.loc[q,field] if q.quarter==4 else (g.loc[q,field]+g.loc[pd.Period(f'{q.year-1}Q4'),field]-g.loc[q-4,field])
        for field in ['total_assets','equity_parent_company']:
            reconstructed[field+'_ttm_0']=g.loc[[q-i for i in range(4)],field].mean()
        for field,value in reconstructed.items():
            vendor=float(inputs.loc[stock,field])
            error=abs(value-vendor)/max(abs(vendor),1)
            pit_checks.append(dict(query_date=date,stock=stock,latest_quarter=str(q),field=field,
                reconstructed=value,vendor_value=vendor,relative_error=error,
                max_info_date=pd.to_datetime(g.info_date).max()))
    # Independently verify the three exact factor formulas from cached inputs.
    for stock,r in inputs.iterrows():
        for factor,value in [('bm',r.equity_parent_company_ttm_0/r.market_cap_3),
                             ('ep',r.net_profit_parent_company_ttm_0/r.market_cap_3),
                             ('roa',r.net_profit_ttm_0/r.total_assets_ttm_0)]:
            vendor=r[{v:k for k,v in mapping.items()}[factor]]
            pit_checks.append(dict(query_date=date,stock=stock,latest_quarter='',field=factor,
                reconstructed=value,vendor_value=vendor,relative_error=abs(value-vendor)/max(abs(vendor),1),max_info_date=date))
pit=pd.DataFrame(pit_checks)
pit.to_csv(AUDIT/'pit_formula_crosschecks.csv',index=False)
assert pit.relative_error.lt(1e-6).all(),pit.loc[pit.relative_error.ge(1e-6)].to_string()

# Post-adjusted levels may differ by <=0.00005 due to the local 4-decimal export.
price_checks=[]
for file in sorted(RAW.glob('price_post_*.parquet')):
    r=pd.read_parquet(file).reset_index()
    code=r.order_book_id.iloc[0].replace('.XSHG','.SH').replace('.XSHE','.SZ')
    local=load_local('daily_adj_close_post_20260630.pkl')[code].reindex(r.date).to_numpy()
    good=np.isfinite(local)&r.close.notna().to_numpy()
    err=np.abs(local[good]-r.close.to_numpy()[good])
    price_checks.append(dict(stock=code,overlap_days=int(good.sum()),max_abs_price_difference=float(err.max()),
                              median_abs_price_difference=float(np.median(err))))
pd.DataFrame(price_checks).to_csv(AUDIT/'rqdata_price_crosscheck.csv',index=False)
assert len(list(RAW.glob('prices_20*.parquet')))==19, 'Use the refreshed source price vintage after overlap differences.'
price_corrections=[]
local_close=load_local('daily_close_none_20260630.pkl')
for path in sorted(RAW.glob('price_none_*.parquet')):
    r=pd.read_parquet(path).reset_index()
    code=r.order_book_id.iloc[0].replace('.XSHG','.SH').replace('.XSHE','.SZ')
    r['local']=local_close[code].reindex(r.date).to_numpy()
    for row in r.loc[(r.close-r.local).abs().gt(1e-8)].itertuples():
        price_corrections.append(dict(stock=code,date=row.date,local_unadjusted=row.local,
                                     refreshed_unadjusted=row.close,difference=row.close-row.local))
pd.DataFrame(price_corrections).to_csv(AUDIT/'raw_price_vintage_differences.csv',index=False)
turn=pd.read_parquet(RAW/'turnover_verification.parquet').reset_index()
local=load_local('daily_turnover_rate_20260630.pkl')
turn['stock']=turn.order_book_id.str.replace('.XSHG','.SH',regex=False).str.replace('.XSHE','.SZ',regex=False)
turn['local']=[local.at[r.tradedate,r.stock] for r in turn.itertuples()]
assert np.allclose(turn.today,turn.local,rtol=1e-10)
turn.to_csv(AUDIT/'rqdata_turnover_crosscheck.csv',index=False)

features=['momentum','reversal','bm','ep','size','roa','turnover','volatility']
eligible=panel.eligible_at_formation
for feature in features:
    panel[feature]=np.nan
    for month,g in panel.loc[eligible].groupby('formation_month'):
        s=g[feature+'_raw'];n=s.notna().sum()
        assert n>1, (month,feature,'entire cross-section missing')
        panel.loc[g.index,feature]=(2*(s.rank(method='average')-1)/(n-1)-1).fillna(0)
panel['membership_status']=True
panel['pit_financial_verified']=panel.date.notna()
panel['formal_data_ready']=True
panel['price_adjustment_convention_verified']=True
panel['panel_status']='FORMAL_EIGHT_FEATURE_PANEL_WITH_DISCLOSED_MISSING_LABELS'
panel['financial_information_cutoff']=panel.date
shibor=pd.read_parquet(RAW/'shibor_200912_202602.parquet').sort_index()
shibor_values=[]
for r in panel[['entry_date','exit_date']].itertuples(index=False):
    # 1M simple annual percent, ACT/360. Only past/entry-day quotes are used.
    rate=shibor.loc[:r.entry_date,'1M'].iloc[-1]
    shibor_values.append(rate/100*(r.exit_date-r.entry_date).days/360)
panel['rf_shibor_1m_entry_proxy']=shibor_values
assert panel.loc[eligible,features].notna().all().all()
assert panel.loc[eligible,'pit_financial_verified'].all()
assert panel.loc[eligible,features].abs().le(1).all().all()
assert not panel.duplicated(['formation_month','stock']).any()
assert panel.groupby('holding_month').size().eq(500).all()
test=panel.loc[eligible&panel.holding_month.between('2023-01','2025-12')]
assert test.excess_return.notna().all()

panel.to_parquet(ROOT/'data/processed/panel_monthly.parquet',index=False)
for col in features:
    panel.groupby('holding_month')[col+'_raw'].apply(lambda x:x.isna().mean()).rename(col).to_csv(AUDIT/f'missing_{col}.csv')
desc=panel.loc[eligible,[x+'_raw' for x in features]].describe(percentiles=[.01,.5,.99]).T
desc.to_csv(ROOT/'results/tables/predictor_descriptive_statistics.csv')
coverage=panel.groupby('holding_month').agg(members=('stock','size'),eligible=('eligible_at_formation','sum'),
    missing_y=('excess_return',lambda x:x.isna().sum()))
for feature in features:
    coverage[feature+'_missing_eligible']=panel.loc[eligible].groupby('holding_month')[feature+'_raw'].apply(lambda x:x.isna().sum())
coverage.to_csv(AUDIT/'final_monthly_coverage.csv')
panel.loc[~panel.label_evaluable].to_csv(AUDIT/'missing_return_labels.csv',index=False)
status=dict(formal_data_ready=True,status='READY_WITH_DISCLOSED_LIMITATIONS',features=features,
    source='Local audited market data + explicit-date RQData historical membership and PIT factors',
    primary_rf='CSMAR NRI01 annual deposit proxy, documented 365-day compounding',
    missing_training_validation_labels=int((eligible&panel.excess_return.isna()).sum()),
    test_all_exante_stocks_have_y=True,pit_formula_checks=len(pit),
    max_pit_formula_relative_error=float(pit.relative_error.max()),
    limitations=['A-share capitalization for Size, not total-company/free-float cap',
                 'A few historical missing return labels excluded explicitly from estimation',
                 'Historical exchange code 600849 lacks licensed RQData price history',
                 'Portfolio returns are theoretical; order execution is not observed',
                 'Vendor historical as-of reconstruction is not proof of contemporaneous database delivery'],
    panel_sha256=sha256(ROOT/'data/processed/panel_monthly.parquet'))
(ROOT/'data/processed/data_status.json').write_text(json.dumps(status,ensure_ascii=False,indent=2))
(AUDIT/'rqdata_verification_summary.json').write_text(json.dumps(status,ensure_ascii=False,indent=2))
print(json.dumps(status,ensure_ascii=False,indent=2))
