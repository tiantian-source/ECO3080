"""Generate interpretation only after real prediction/backtest outputs exist."""
import json
import numpy as np
import pandas as pd
from common import ROOT,AUDIT,md_table,sha256

T=ROOT/'results/tables';R=ROOT/'reports'
metrics=pd.read_csv(T/'model_performance.csv')
forecast=pd.read_csv(T/'forecast_comparison.csv')
port=pd.read_csv(T/'portfolio_performance.csv')
importance=pd.read_csv(T/'feature_importance.csv')
application=pd.read_csv(T/'application_portfolio.csv')
panel=pd.read_parquet(ROOT/'data/processed/panel_monthly.parquet')
eligible=panel.loc[panel.eligible_at_formation]
counts=[]
for name,begin,end in [('Training','2010-01','2020-12'),('Validation','2021-01','2022-12'),
                        ('Testing','2023-01','2025-12'),('Application','2026-01','2026-01')]:
    sub=panel.loc[panel.holding_month.between(begin,end)]
    e=sub.loc[sub.eligible_at_formation]
    counts.append(dict(period=name,holding_start=begin,holding_end=end,months=sub.holding_month.nunique(),
        historical_members=len(sub),eligible_observations=len(e),eligible_stocks=e.stock.nunique(),
        missing_eligible_y=int(e.excess_return.isna().sum()),
        minimum_eligible_per_month=int(e.groupby('holding_month').size().min()),
        maximum_eligible_per_month=int(e.groupby('holding_month').size().max())))
data_summary=pd.DataFrame(counts)
data_summary.to_csv(T/'data_summary.csv',index=False)
definitions=pd.DataFrame([
    ['momentum','P(t-1) / P(t-12) - 1; skip most recent month','decimal return'],
    ['reversal','-[P(t) / P(t-1) - 1]','decimal return'],
    ['bm','PIT equity_parent_company_ttm_0 / market_cap_3','ratio'],
    ['ep','PIT net_profit_parent_company_ttm_0 / market_cap_3','ratio'],
    ['size','ln(a_share_market_val_3)','log CNY'],
    ['roa','PIT net_profit_ttm_0 / total_assets_ttm_0','ratio'],
    ['turnover','Mean of 21 market-day turnover rates through formation','percentage points per day'],
    ['volatility','Sample standard deviation of 21 adjusted daily returns','decimal return per day']],
    columns=['feature','definition','raw_unit'])
description=pd.read_csv(T/'predictor_descriptive_statistics.csv').rename(columns={'Unnamed: 0':'feature'})
description.feature=description.feature.str.removesuffix('_raw')
definitions.merge(description,on='feature',validate='one_to_one').to_csv(T/'predictor_definitions_and_statistics.csv',index=False)
best_prediction=metrics.sort_values('oos_r2',ascending=False).iloc[0]
d10=port.loc[port.portfolio.eq('D10')]
best_portfolio=d10.sort_values('annualized_return',ascending=False).iloc[0]
best_sharpe=d10.sort_values('sharpe',ascending=False).iloc[0]
best_drawdown=d10.sort_values('maximum_drawdown',ascending=False).iloc[0]
ew=port.loc[port.model.eq('EW')].iloc[0]

metric_display=metrics[['model','oos_r2','rmse','mae']].copy()
for col in ['oos_r2','rmse','mae']:
    metric_display[col]=metric_display[col].map(lambda x:f'{x*100:.4f}%')
forecast_display=forecast[['model','mean_mse_improvement','nw_standard_error','nw_t_stat','p_value']].copy()
for col in ['mean_mse_improvement','nw_standard_error']:
    forecast_display[col]=forecast_display[col].map(lambda x:f'{x:.8g}')
for col in ['nw_t_stat','p_value']:
    forecast_display[col]=forecast_display[col].map(lambda x:f'{x:.4f}')
portfolio_display=port[['model','portfolio','annualized_return','annualized_volatility','sharpe','maximum_drawdown','mean_one_way_turnover']].copy()
for col in ['annualized_return','annualized_volatility','maximum_drawdown','mean_one_way_turnover']:
    portfolio_display[col]=portfolio_display[col].map(lambda x:f'{x*100:.2f}%')
portfolio_display.sharpe=portfolio_display.sharpe.map(lambda x:f'{x:.3f}')

findings=[]
ols=metrics.set_index('model').loc['OLS','oos_r2']
for row in forecast.itertuples():
    r2=metrics.set_index('model').loc[row.model,'oos_r2']
    findings.append(f'- {row.model}相对OLS：OOS R²差为{100*(r2-ols):+.4f}个百分点；月均MSE改善{row.mean_mse_improvement:+.8g}，NW t={row.nw_t_stat:.3f}，双侧p={row.p_value:.4f}。'+
        ('在预设5%水平上有差异。' if row.p_value<.05 else '在预设5%水平上未发现显著差异。'))
top_features=[]
for model in ['RF','MLP']:
    top=importance.loc[importance.model.eq(model)].sort_values('mean',ascending=False).head(3)
    top_features.append(model+'：'+', '.join(f'{r.feature} ({r.mean:+.7f})' for r in top.itertuples()))
feasibility=pd.read_csv(T/'trading_feasibility.csv')
diag=feasibility.loc[feasibility.portfolio.isin(['D10','ALL'])].groupby('model')[
    ['entry_suspended','entry_limit_up','exit_suspended','exit_limit_down','missing_return']].sum().reset_index()
diag.to_csv(T/'trading_feasibility_summary.csv',index=False)
frozen=json.loads((ROOT/'results/frozen_hyperparameters.json').read_text())
selected=pd.DataFrame([dict(model=k,candidate=v['candidate'],settings=json.dumps(v['settings'])) for k,v in frozen['models'].items()])
raw_missing=pd.read_csv(T/'feature_coverage.csv')
app_display=application[['model','portfolio','stocks','raw_return','rf_return']].copy()
for col in ['raw_return','rf_return']:
    app_display[col]=app_display[col].map(lambda x:f'{100*x:.4f}%')
same=best_prediction.model==best_portfolio.model
rank_compare=metrics[['model','oos_r2']].merge(d10[['model','annualized_return']],on='model')
rank_compare['prediction_rank']=rank_compare.oos_r2.rank(ascending=False).astype(int)
rank_compare['D10_return_rank']=rank_compare.annualized_return.rank(ascending=False).astype(int)
rank_compare.to_csv(T/'model_rank_comparison.csv',index=False)
summary=f'''# Comparing Models for CSI 500 Excess Return Prediction — 研究结果

运行日期：2026-11-15。以下数字全部来自当前Workspace真实数据和实际执行结果。完整研究规范为正式六页Proposal；没有使用早期Top20%/三模型方案。主结果是**八因子、四模型、2023–2025持有月样本外预测及理论组合回测**。2026-01单列，不参与调参。

## 1. 主要研究发现

预测OOS R²最高、RMSE最低的模型是 **{best_prediction.model}**：R²={best_prediction.oos_r2*100:.4f}%，RMSE={best_prediction.rmse*100:.4f}%，MAE={best_prediction.mae*100:.4f}%。D10年化收益最高的是 **{best_portfolio.model}**，CAGR={best_portfolio.annualized_return*100:.2f}%；Sharpe最高为 **{best_sharpe.model}**（{best_sharpe.sharpe:.3f}），最大回撤最小为 **{best_drawdown.model}**（{best_drawdown.maximum_drawdown*100:.2f}%）。

最佳预测与最佳D10收益模型{'相同' if same else '不同'}。这是本样本中模型排名的描述，四个模型和36个月不能用来识别“预测精度提升导致投资收益提升”的因果关系。R²衡量所有股票的平方误差，D10回报依赖最高预测尾部的排序和实际收益；二者排序即使一致，也不证明普遍转化关系。

## 2. 数据与样本

{md_table(data_summary)}

原始审计76个文件、22 PKL和16 ZIP；使用已验证的本地换手率、市值、交易状态和CSMAR NRI01利率。RQData补充193个月历史名单、PIT财务因子、原始财报历史版本、统一版本的后复权价格、SHIBOR与核验资料。最终价格2008-12至2026-02足够支持回看及最后退出。没有对最新名单进行历史回填。

{md_table(raw_missing)}

偶发X缺失仅填横截面中性值0；原始财务值保留。Size为ln(A股总市值)。BM是权益TTM平均/公司总市值，EP是归母净利TTM/公司总市值，ROA是净利润TTM/资产TTM平均。CSMAR ROA口径不同，未混用；RQData的PIT接口说明及84项历史版本/公式核查见`02_rqdata_completion.md`。三条早期600849记录缺历史行情而在形成时不合格；另有6条合格训练/验证标签缺失被明确排除，存在小量非随机缺失风险。

## 3. 预测及统计检验

{md_table(metric_display)}

R²以零超额收益为基准，非sklearn默认中心化R²。所有模型在相同17957条测试股票月上评价，测试期36个月。收益不截尾、不用0填缺失。主rf为按实际持有日数折算的NRI01代理，超额收益不减CSI500。

{md_table(forecast_display)}

正MSE改善代表模型误差低于OLS。HAC使用36个月的横截面平均损失差，Bartlett核、固定lag=3、小样本校正、t分布df=35双侧p。没有将股票误差视作独立时间观测；没有因不显著改样本或重调模型。p值为三项计划比较各自的名义p值，未作多重比较调整；MLP接近5%边界的发现尤其需要谨慎。

{chr(10).join(findings)}

非线性ML是否有额外价值应同时看以上RF/MLP误差差异与下方D10收益，不能仅因模型复杂就宣称优于线性模型。训练误差与验证误差已保存`validation_folds.csv`；即使训练拟合改善，若没有验证/OOS改善，也只能认为复杂度没有稳定帮助，不能从一个短测试期证明一般过拟合规律。

## 4. 模型设定与边界

{md_table(selected)}

验证24个持有月逐月扩展重估，均仅用已经实现的Y。首个2021-01预测使用至2020-11的标签。**冻结于2022-12-30时，2022-12标签未实现，因此仅用前23个验证月选参数**；2022-12预测与损失只作描述。测试于2022、2023、2024年12月末分别估计一次，年内每月换X并重新选股。超参数保持冻结。

MLP使用全批次Adam、ReLU、预设三种子3080/3081/3082平均预测；训练Y仅以各fold训练均值/标准差缩放，预测还原至原收益单位。固定epoch，无随机验证块或随机时间切分。原quant的Torch多线程dtype转换发生底层崩溃，改为连续float32 NumPy缓冲及单线程后正常运行；未更新环境、未因结果改变结构/网格。

## 5. 组合评价

{md_table(portfolio_display)}

EW同池基准年化收益为{100*ew.annualized_return:.2f}%、Sharpe={ew.sharpe:.3f}。LASSO相对EW的CAGR优势仅{100*(best_portfolio.annualized_return-ew.annualized_return):.3f}个百分点，不能仅凭这点差异宣称稳定超额投资价值。VW用形成日已知A股市值构造。所有股票先按预测收益、再按股票代码确定并列顺序，按位置分十组，组内等权；每组人数最多差1。实际净值使用原始调整收益而非预测值或Y。`prediction_tie_diagnostics.csv`披露预测并列情况，常数预测下的分组只反映固定并列规则。

{md_table(rank_compare[['model','prediction_rank','D10_return_rank']])}

本次四个D10-D1合成序列均为负，十分位平均收益也不单调增加。这不支持稳定的高预测减低预测排序收益。最佳模型在两个维度都为LASSO，但MLP的预测排名高于RF、D10收益排名却低于RF，模型排名并不完全一致。正OOS R²相对零预测的改善也可能包含共同收益水平的预测，不能自动解释为有效横截面选股。

年化收益为CAGR，波动率为月标准差×√12；长仓Sharpe使用月度组合收益减匹配rf后计算均值/标准差×√12。最大回撤净值含期初1。换手先让上期权重随收益漂移，再计算含现金的半L1距离；平均换手排除初始建仓。D10-D1按一元多头减一元空头、总敞口2的合成序列展示，Sharpe以零为自融资spread基准，CAGR是合成归一化财富路径，并非验证的可执行资本收益率。

## 6. 可交易性、成本和解释限制

{md_table(diag)}

表中为36个月端点状态计数，不代表独立股票数，也不代表实际成交失败订单数。理论收益未把选出的停牌/涨跌停股票事后删去或补选；存在报价不等于能成交。没有逐笔订单/排队、退市现金换股终值及完整借券成本，故不把理论sorting收益称为实际可执行策略净收益。

`transaction_cost_sensitivity.csv`预先设0/10/25/50bps每元股票交易金额，按漂移后买卖合计名义额计算费用；假设入场支付成本，净收益=(1−成本率×交易名义额)×(1+毛收益)−1。这是假设成本敏感性，不是观测佣金/印花税。1M SHIBOR按Entry日已公布报价、ACT/360简单折算，仅用于Sharpe敏感性；未用将来的利率作为形成时X。

预测重要性（置换导致的MSE增加，越大越重要）：{'；'.join(top_features)}。采用同月内置换以保持月份分布、三个固定置换种子；不改变正式因子，也不据此重训同一测试集。相关变量会分摊重要性，负重要性可能来自噪声；均不解释为因果效应。LASSO/OLS系数另见`linear_coefficients.csv`。

## 7. January 2026独立应用

站在2025-12-31，使用至2025-11已完成标签与当日特征；2025-12持有期标签没有进入训练。Entry为2026-01-05收盘、Exit为2026-02-02收盘；不使用该月结果选择模型。所有497只合格股票均有预测及实际Y。

{md_table(app_display)}

具体每只D10股票、权重和真实收益见`results/tables/application_d10_holdings.csv`。一个月结果不能替代主测试，也不能用于宣称模型在未来必然优越。

## 8. 可以写入正式Paper的内容

可以据实使用本次四模型预测表、月度HAC比较、D1–D10理论收益、D10与同池EW/VW比较、预设成本敏感性和预测重要性；同时保留PIT来源、日期边界、缺标签及代码事件说明。不能写成“证明ML普遍优于OLS”“显著性来自几万独立股票月”“所有组合可按报价成交”“本研究识别预测准确度导致回报增加”。

测试期只有36个月，统计功效有限；金融尾部事件可能主导平方误差和财富曲线。横截面相关、历史数据供应商重建、A股市值口径、NRI01/SHIBOR代理的期限/信用风险，以及训练/验证少量缺失标签，均限制外推。论文结果适用于本次事前规则下的合格历史CSI500样本，不能覆盖所有A股或保证未来投资表现。

## 9. 复现与图表

所有模型和组合来自保存的同一份OOS预测，数据与配置哈希见`model_run_manifest.json`。README列出已有环境的完整执行顺序。七份Notebook已执行核对，展示真实表格及抽样复现；不会沿用旧Notebook的过期数字。

- Figure 1：`results/figures/cumulative_d10.png`
- Figure 2：`results/figures/decile_performance.png`
- Figure 3：`results/figures/prediction_performance.png`
- Figure 4：`results/figures/feature_importance.png`
- 理论多空路径：`results/figures/cumulative_long_short.png`
'''
(R/'research_results_summary.md').write_text(summary)

outline='''# Paper Outline — maximum 15 pages

正文目标约12–13页，参考文献及必要附表占余下篇幅。下面区分设计、实际结果、解释和限制；不把理论组合写成已验证的实际成交收益。

1. **Abstract（约0.5页）**：研究对象、八特征和四模型；2010–2020训练、2021–2022验证、2023–2025测试；以真实model_performance和portfolio_performance中数字报告主要发现及36个月局限。
2. **Introduction（约1页）**：提出统计预测与组合收益两个问题，说明预测与投资收益排名未必一致；本研究是受限股票池和小特征集的比较，不是普遍ML优势或因果转化检验。
3. **Literature Review（约1页）**：Gu, Kelly & Xiu (2020)提供预测/排序组合比较框架；Leippold, Wang & Zhou (2022)提供中国市场背景。说明样本、八特征、纯LASSO、执行日和较短测试期属于本项目改编，不声称完整复现。
4. **Data（约2页）**：历史成员及股票代码、RQData与本地数据交叉核验、PIT及财报修订、表1样本与表2因子定义/覆盖；说明600849缺历史行情及6个较早合格标签缺失。列明A股市值、BM/ROA TTM分母、利率代理。
5. **Methodology（约2页）**：精确定义形成/Entry/Exit和超额收益；八因子与排名；共同样本；月度扩展验证、仅23个可见验证月冻结参数、年度重估；平方误差目标与3种子MLP；零预测OOS R²和月度HAC lag3。
6. **Empirical Results（约2页）**：表3预测性能与表4HAC；图3性能、图4置换重要性。真实比较各模型，区分经济量级与p值，不因不显著换样本，不作重要性的因果解释。
7. **Portfolio Evaluation（约2页）**：表5 D10/EW/VW与理论spread、图1财富曲线、图2十分位收益；说明漂移换手、匹配rf和期初净值；用短段比较最佳预测与最佳投资模型，讨论尾部/排序可能解释；成本及成交障碍可置附表。2026-01作为0.5页独立历史例子或附录。
8. **Conclusion（约0.5页）**：仅总结实际结果、适用样本和局限，提出未来更长测试/执行数据验证；不宣称可交易套利或保证回报。
9. **References（约1页）**：
   - Gu, S., Kelly, B., & Xiu, D. (2020). Empirical Asset Pricing via Machine Learning. *Review of Financial Studies*, 33(5), 2223–2273. https://doi.org/10.1093/rfs/hhaa009
   - Leippold, M., Wang, Q., & Zhou, W. (2022). Machine learning in the Chinese stock market. *Journal of Financial Economics*, 145, 64–82. https://doi.org/10.1016/j.jfineco.2021.08.017
   - RiceQuant RQData官方API/财务PIT文档、CSMAR NRI01字段字典、SHIBOR实施准则；记录访问/下载日2026-11-15。

正式排版时优先保留5张主表和4张必要图，将逐月覆盖、完整参数网格、年度估计审计、交易限制计数与全部应用持仓放入复现附件，避免挤满15页。
'''
(R/'paper_outline.md').write_text(outline)

draft=f'''# Empirical Results — English Working Draft

This study compares pooled OLS, LASSO, Random Forest and a small MLP using eight monthly characteristics of historical CSI 500 constituents. The main test contains 17,957 eligible stock-month observations over January 2023–December 2025. Each target is the adjusted first-trading-day-close to following first-trading-day-close stock return less a matching RMB risk-free proxy. Historical membership and financial characteristics are retrieved as of the formation date; the data and timing checks are documented separately.

{best_prediction.model} achieves the highest out-of-sample R-squared ({best_prediction.oos_r2*100:.4f}%) and the lowest RMSE ({best_prediction.rmse*100:.4f}%). The R-squared benchmark is a forecast of zero excess return. The formal comparisons aggregate stock-level squared-error differences within each month and use Newey–West standard errors with three lags and a small-sample t reference distribution. Inference therefore rests on 36 monthly differences. The complete estimates and p-values appear in Table 4; the short test period limits power and warrants cautious interpretation.

The highest annualized D10 return is obtained by {best_portfolio.model} ({best_portfolio.annualized_return*100:.2f}%), compared with {ew.annualized_return*100:.2f}% for the eligible-universe equal-weighted benchmark. The model with the best predictive R-squared and the model with the highest D10 return {'are the same' if same else 'differ'}. These rankings describe the realized sample and do not establish a causal relation between forecast accuracy and investment performance. Squared-error accuracy weights the entire cross-section, whereas D10 performance depends on the ranking of a small upper tail and its realized returns.

Portfolio returns are theoretical sorting returns before trading costs. Suspension and price-limit diagnostics are reported separately; observed quotes do not establish that an order could have been executed. The D10–D1 series assumes unit long and short notionals and excludes borrowing and margin-financing costs. Results also depend on the A-share capitalization convention, the RMB interest-rate proxy, vendor historical reconstruction, and six missing earlier eligible labels excluded from estimation or validation loss evaluation. The January 2026 exercise is presented separately and has no role in hyperparameter selection. These qualifications should accompany every substantive conclusion in the final paper.
'''
(R/'empirical_results_draft_en.md').write_text(draft)
print('Research summary, paper outline, and English empirical-results draft saved.')
