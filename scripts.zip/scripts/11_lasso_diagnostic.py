"""Read-only diagnosis of frozen ECO3080 results. No fitting, tuning or downloads.

Writes only reports/lasso_diagnostic.md and reports/diagnostics/lasso/*.
"""
import json
from itertools import combinations
from pathlib import Path
import numpy as np
import pandas as pd
from common import ROOT,sha256,md_table

OUT=ROOT/'reports/diagnostics/lasso'
OUT.mkdir(parents=True,exist_ok=True)
MODELS=['OLS','LASSO','RF','MLP']
CONFIG=json.loads((ROOT/'research_config.json').read_text())
FEATURES=CONFIG['features']

# Protect all pre-existing official artifacts, including executed notebooks.
protected=[p for folder in ['results','data/processed','notebooks'] for p in (ROOT/folder).rglob('*') if p.is_file()]
protected += [ROOT/'research_config.json',ROOT/'README.md',ROOT/'requirements.txt']
protected += [p for p in (ROOT/'scripts').glob('*.py') if p.name!='11_lasso_diagnostic.py']
protected += list((ROOT/'reports').glob('*.md'))
protected=[p for p in protected if p.name!='lasso_diagnostic.md']
before={str(p.relative_to(ROOT)):dict(sha256=sha256(p),mtime_ns=p.stat().st_mtime_ns) for p in protected}

P=ROOT/'results/predictions';T=ROOT/'results/tables'
oos=pd.read_parquet(P/'oos_predictions.parquet')
panel=pd.read_parquet(ROOT/'data/processed/panel_monthly.parquet')
coeff=pd.read_csv(T/'linear_coefficients.csv')
ties_saved=pd.read_csv(T/'prediction_tie_diagnostics.csv').set_index('holding_month')
folds=pd.read_csv(T/'validation_folds.csv')
valid_pred=pd.read_parquet(P/'validation_predictions.parquet')
weights=pd.read_parquet(P/'portfolio_weights.parquet')
decile_saved=pd.read_csv(T/'decile_returns.csv')
annual_audit=pd.read_csv(T/'model_estimation_audit.csv')
frozen=json.loads((ROOT/'results/frozen_hyperparameters.json').read_text())
run=json.loads((ROOT/'results/model_run_manifest.json').read_text())
oos['year']=oos.holding_month.str[:4].astype(int)
assert len(oos)==17957 and oos.holding_month.nunique()==36
assert not oos.duplicated(['holding_month','stock']).any()
assert oos.actual_excess_return.notna().all()

def save(name,data):
    data.to_csv(OUT/(name+'.csv'),index=False)

def table(data,formats=None):
    d=data.copy()
    for col,fmt in (formats or {}).items():
        d[col]=d[col].map(lambda x:fmt.format(x) if pd.notna(x) else 'NA')
    return md_table(d)

# 1. Linear coefficients, support stability and intercept reconstruction.
lasso=coeff.loc[coeff.model.eq('LASSO')&coeff.year.between(2023,2025)].copy()
matrix=lasso.pivot(index='feature',columns='year',values='coefficient').reindex(FEATURES)
coef_summary=[];linear_checks=[];stability=[];turnover_mechanism=[]
for year in [2023,2024,2025]:
    c=matrix[year];b=float(lasso.loc[lasso.year.eq(year),'intercept'].iloc[0])
    estimate_date=pd.to_datetime(oos.loc[oos.year.eq(year),'model_estimation_date'].iloc[0])
    tr=panel.loc[panel.eligible_at_formation&panel.excess_return.notna()&panel.label_available_date.le(estimate_date)&panel.holding_month.ge('2010-01')]
    coef_summary.append(dict(year=year,nonzero_exact=int(c.ne(0).sum()),nonzero_tol1e_12=int(c.abs().gt(1e-12).sum()),
        nonzero_features=', '.join(c.index[c.abs().gt(1e-12)]),intercept=b,
        max_abs_coefficient=c.abs().max(),l1_norm=c.abs().sum(),
        turnover_abs_share=c.loc['turnover'].__abs__()/c.abs().sum(),
        turnover_squared_share=c.loc['turnover']**2/(c**2).sum(),
        mean_training_y=tr.excess_return.mean(),
        intercept_identity_error=abs(b-(tr.excess_return.mean()-tr[FEATURES].mean().dot(c))),
        training_y_sd=tr.excess_return.std(ddof=0)))
    for model in ['OLS','LASSO']:
        cmod=coeff.loc[coeff.model.eq(model)&coeff.year.eq(year)].set_index('feature')
        beta=cmod.loc[FEATURES,'coefficient'].to_numpy();intercept=cmod.intercept.iloc[0]
        g=oos.loc[oos.year.eq(year)]
        rebuilt=g[FEATURES].to_numpy()@beta+intercept
        error=np.abs(rebuilt-g[model+'_pred'].to_numpy())
        linear_checks.append(dict(year=year,model=model,observations=len(g),max_prediction_error=error.max(),
            intercept=intercept,max_monthly_mean_minus_intercept=g.groupby('holding_month')[model+'_pred'].mean().sub(intercept).abs().max()))
        assert error.max()<1e-12
for a,b in combinations([2023,2024,2025],2):
    ca,cb=matrix[a],matrix[b];sa=set(ca.index[ca.abs().gt(1e-12)]);sb=set(cb.index[cb.abs().gt(1e-12)])
    stability.append(dict(year_a=a,year_b=b,support_jaccard=len(sa&sb)/len(sa|sb),
        cosine=np.dot(ca,cb)/(np.linalg.norm(ca)*np.linalg.norm(cb)),
        retained_same_sign=sum(np.sign(ca[f])==np.sign(cb[f]) for f in sa&sb),common_nonzero=len(sa&sb)))
coef_summary=pd.DataFrame(coef_summary);linear_checks=pd.DataFrame(linear_checks)
save('lasso_coefficients',lasso);save('lasso_coefficient_summary',coef_summary)
save('lasso_coefficient_stability',pd.DataFrame(stability));save('linear_prediction_reconstruction',linear_checks)

# 2/3/4/7. Monthly dispersion, exact ties, IC, independent deciles and SSE identity.
monthly=[];r2parts=[];decile_rows=[];sort_checks=[];group_labels=[]
for month,g in oos.groupby('holding_month',sort=True):
    n=len(g);y=g.actual_excess_return.to_numpy();mu=y.mean();yd=y-mu
    for model in MODELS:
        score=g[model+'_pred'].to_numpy()
        # Independent numpy lexsort, not the production pandas sorting function.
        order=np.lexsort((g.stock.to_numpy(),score))
        labels=np.empty(n,dtype=int);labels[order]=1+(np.arange(n)*10//n)
        k=int((labels==10).sum());cut=float(score[order[n-k]])
        boundary=score==cut;chosen=(labels==10)&boundary
        group_size=int(boundary.sum());inside=int(chosen.sum());outside=group_size-inside
        split=inside>0 and outside>0
        base_sum=g.loc[(labels==10)&~boundary,'actual_raw_return'].sum()
        boundary_returns=np.sort(g.loc[boundary,'actual_raw_return'].to_numpy())
        lower=(base_sum+boundary_returns[:inside].sum())/k
        upper=(base_sum+boundary_returns[-inside:].sum())/k
        pred_mean=score.mean();pdv=score-pred_mean
        rank_ic=g[model+'_pred'].corr(g.actual_excess_return,method='spearman')
        raw_ic=g[model+'_pred'].corr(g.actual_raw_return,method='spearman')
        assert np.isclose(rank_ic,raw_ic)
        unique=int(pd.Series(score).nunique());assert unique==ties_saved.at[month,model+'_pred']
        monthly.append(dict(model=model,holding_month=month,year=int(month[:4]),stocks=n,
            pred_mean=pred_mean,pred_sd=float(np.std(score,ddof=1)),actual_sd=float(np.std(y,ddof=1)),
            pred_sd_to_actual_sd=float(np.std(score)/np.std(y)),unique_exact=unique,
            unique_rounded6=int(pd.Series(score).round(6).nunique()),max_exact_tie=int(pd.Series(score).value_counts().max()),
            d10_count=k,d10_boundary_value=cut,d10_boundary_tie_group=group_size,
            d10_boundary_selected=inside,d10_boundary_excluded=outside,d10_boundary_split=split,
            max_possible_d10_swaps=min(inside,outside),d10_return_lower_tie_bound=lower,
            d10_return_upper_tie_bound=upper,d10_tie_bound_width=upper-lower,
            rank_ic=rank_ic,pearson_ic=g[model+'_pred'].corr(g.actual_excess_return)))
        sse=np.sum((y-score)**2);sse_common=n*(mu-pred_mean)**2;sse_cs=np.sum((yd-pdv)**2)
        assert np.isclose(sse,sse_common+sse_cs,atol=1e-12)
        denominator=np.sum(y*y);common_den=n*mu*mu;cs_den=np.sum(yd*yd)
        assert np.isclose(denominator,common_den+cs_den)
        r2parts.append(dict(model=model,holding_month=month,year=int(month[:4]),n=n,
            zero_ssy=denominator,sse=sse,common_sse=sse_common,cs_sse=sse_cs,
            common_denominator=common_den,cs_denominator=cs_den,
            common_gain=common_den-sse_common,cs_gain=cs_den-sse_cs,
            mse=sse/n,mae=np.abs(y-score).mean(),actual_mean=mu,pred_mean=pred_mean))
        limits=[]
        for decile in range(1,11):
            sub=g.loc[labels==decile]
            ret=float(sub.actual_raw_return.mean())
            key=(month,model,f'D{decile}')
            saved_w=weights.loc[weights.holding_month.eq(month)&weights.model.eq(model)&weights.portfolio.eq(f'D{decile}')]
            same_set=set(saved_w.stock)==set(sub.stock)
            same_weight=bool(np.allclose(saved_w.weight,1/len(sub)))
            saved_r=decile_saved.loc[decile_saved.holding_month.eq(month)&decile_saved.model.eq(model)&decile_saved.portfolio.eq(f'D{decile}'),'raw_return'].iloc[0]
            sort_checks.append(dict(holding_month=month,model=model,decile=decile,
                stocks=len(sub),same_saved_members=same_set,same_equal_weights=same_weight,
                return_abs_error=abs(ret-saved_r),pred_min=float(sub[model+'_pred'].min()),
                pred_max=float(sub[model+'_pred'].max()),pred_mean=float(sub[model+'_pred'].mean())))
            assert same_set and same_weight and abs(ret-saved_r)<1e-12
            limits.append((sub[model+'_pred'].min(),sub[model+'_pred'].max()))
            decile_rows.append(dict(holding_month=month,year=int(month[:4]),model=model,decile=decile,
                raw_return=ret,pred_mean=float(sub[model+'_pred'].mean()),stocks=len(sub)))
        assert all(limits[j][1]<=limits[j+1][0] for j in range(9))
        group_labels.append(pd.DataFrame({'holding_month':month,'model':model,'stock':g.stock.to_numpy(),'decile':labels}))
        if model=='LASSO':
            turn_order=np.lexsort((g.stock.to_numpy(),-g.turnover.to_numpy()))
            low_turnover_top=set(g.iloc[turn_order[-k:]].stock)
            turnover_mechanism.append(dict(holding_month=month,year=int(month[:4]),
                corr_with_negative_turnover=g.LASSO_pred.corr(-g.turnover,method='spearman'),
                d10_low_turnover_overlap=len(set(g.loc[labels==10,'stock'])&low_turnover_top)/k))
monthly=pd.DataFrame(monthly);parts=pd.DataFrame(r2parts);deciles=pd.DataFrame(decile_rows)
sort_checks=pd.DataFrame(sort_checks)
save('monthly_prediction_dispersion_ties_ic',monthly)
save('monthly_loss_decomposition',parts);save('decile_sort_independent_checks',sort_checks)
save('lasso_turnover_mechanism',pd.DataFrame(turnover_mechanism))

ic_summary=[];decomposition=[];prediction_annual=[]
for period,subset in [('2023-2025',monthly)]+[(str(y),monthly.loc[monthly.year.eq(y)]) for y in [2023,2024,2025]]:
    for model,g in subset.groupby('model',sort=False):
        ic_summary.append(dict(period=period,model=model,months=len(g),mean_rank_ic=g.rank_ic.mean(),
            median_rank_ic=g.rank_ic.median(),positive_ic_fraction=g.rank_ic.gt(0).mean(),
            mean_pearson_ic=g.pearson_ic.mean(),ic_sd=g.rank_ic.std(ddof=1)))
    part_subset=parts if period=='2023-2025' else parts.loc[parts.year.eq(int(period))]
    obs=oos if period=='2023-2025' else oos.loc[oos.year.eq(int(period))]
    for model,g in part_subset.groupby('model',sort=False):
        s=g[['zero_ssy','sse','common_sse','cs_sse','common_denominator','cs_denominator','common_gain','cs_gain','n']].sum()
        overall=1-s.sse/s.zero_ssy
        common_contribution=s.common_gain/s.zero_ssy;cs_contribution=s.cs_gain/s.zero_ssy
        assert np.isclose(overall,common_contribution+cs_contribution)
        decomposition.append(dict(period=period,model=model,oos_r2=overall,
            common_contribution_to_r2=common_contribution,cs_contribution_to_r2=cs_contribution,
            centered_cs_r2=1-s.cs_sse/s.cs_denominator,
            mean_prediction_only_r2=1-(s.common_sse+s.cs_denominator)/s.zero_ssy,
            common_denominator_fraction=s.common_denominator/s.zero_ssy,
            total_sse=s.sse,common_sse=s.common_sse,cs_sse=s.cs_sse,
            pooled_sse_common_share=s.common_sse/s.sse))
        error=obs.actual_excess_return-obs[model+'_pred']
        prediction_annual.append(dict(period=period,model=model,observations=len(obs),months=len(g),
            oos_r2=overall,rmse=np.sqrt(np.mean(error**2)),mae=np.mean(np.abs(error))))
ic_summary=pd.DataFrame(ic_summary);decomposition=pd.DataFrame(decomposition)
prediction_annual=pd.DataFrame(prediction_annual)
prediction_annual['r2_rank']=prediction_annual.groupby('period').oos_r2.rank(ascending=False).astype(int)
save('rank_ic_summary',ic_summary);save('loss_decomposition_summary',decomposition);save('prediction_by_year',prediction_annual)
mean_deciles=deciles.groupby(['model','decile'],sort=False).raw_return.mean().unstack('decile').reindex(MODELS)
save('decile_average_monthly_returns',mean_deciles.reset_index())

# 5. Annual portfolios, with correct drift turnover and unchanged saved returns.
portfolio_year=[];spread_months=[]
for model in MODELS:
    tab=deciles.loc[deciles.model.eq(model)].pivot(index='holding_month',columns='decile',values='raw_return')
    for month,row in tab.iterrows():
        original=oos.loc[oos.holding_month.eq(month)].iloc[0]
        spread_months.append(dict(model=model,holding_month=month,year=int(month[:4]),
            entry_date=original.entry_date,exit_date=original.exit_date,d1=row[1],d10=row[10],spread=row[10]-row[1],
            ew=oos.loc[oos.holding_month.eq(month),'actual_raw_return'].mean()))
spread_months=pd.DataFrame(spread_months)
for year in [2023,2024,2025]:
    s=decile_saved.loc[decile_saved.holding_month.str.startswith(str(year))].copy()
    for model in MODELS+['EW','VW']:
        label='D10' if model in MODELS else 'ALL'
        g=s.loc[s.model.eq(model)&s.portfolio.eq(label)].sort_values('holding_month')
        returns=g.raw_return;excess=returns-g.rf_return;wealth=np.r_[1.,np.cumprod(1+returns)]
        turn=g.loc[~g.holding_month.eq('2023-01'),'one_way_turnover']
        row=dict(year=year,model=model,annual_return=wealth[-1]-1,
            annual_volatility=returns.std(ddof=1)*np.sqrt(12),sharpe=excess.mean()/excess.std(ddof=1)*np.sqrt(12),
            max_drawdown=np.min(wealth/np.maximum.accumulate(wealth)-1),mean_one_way_turnover=turn.mean(),
            turnover_months=len(turn))
        if model in MODELS:
            d1=s.loc[s.model.eq(model)&s.portfolio.eq('D1')].sort_values('holding_month').raw_return.to_numpy()
            spread=returns.to_numpy()-d1
            row.update(d1_annual_return=np.prod(1+d1)-1,mean_monthly_spread=spread.mean(),
                synthetic_spread_annual_return=np.prod(1+spread)-1,positive_spread_fraction=np.mean(spread>0))
        portfolio_year.append(row)
portfolio_year=pd.DataFrame(portfolio_year)
portfolio_year['annual_return_rank_among_models']=np.nan
model_mask=portfolio_year.model.isin(MODELS)
portfolio_year.loc[model_mask,'annual_return_rank_among_models']=portfolio_year.loc[model_mask].groupby('year').annual_return.rank(ascending=False)
save('portfolio_by_year',portfolio_year);save('monthly_spreads_and_dates',spread_months)
save('worst_spread_months',spread_months.sort_values('spread').groupby('model',sort=False).head(5).reset_index(drop=True))

# 6. Inspect existing validation folds: never call fit or choose a new setting.
selection=folds.loc[folds.available_for_selection].copy()
selection['train_validation_gap']=selection.validation_mse-selection.training_mse
val_summary=selection.groupby(['model','candidate'],sort=False).agg(months=('holding_month','nunique'),
    train_mse=('training_mse','mean'),validation_mse=('validation_mse','mean'),
    mean_gap=('train_validation_gap','mean'),positive_gap_fraction=('train_validation_gap',lambda x:x.gt(0).mean())).reset_index()
settings=selection.groupby(['model','candidate']).setting.first()
val_summary['settings']=[settings.at[(r.model,r.candidate)] for r in val_summary.itertuples()]
val_summary['frozen_selected']=[r.candidate==frozen['models'][r.model]['candidate'] for r in val_summary.itertuples()]
baseline=selection.loc[selection.model.eq('OLS')].set_index('holding_month')
val_summary['validation_mse_minus_OLS']=val_summary.validation_mse-baseline.validation_mse.mean()
save('validation_candidate_diagnostics',val_summary)
comparison_rows=[]
for model in ['RF','MLP']:
    reference=frozen['models'][model]['candidate']
    base=selection.loc[selection.model.eq(model)&selection.candidate.eq(reference)].set_index('holding_month')
    for candidate,g in selection.loc[selection.model.eq(model)].groupby('candidate'):
        aligned=g.set_index('holding_month').loc[base.index]
        comparison_rows.append(dict(model=model,candidate=candidate,frozen_reference=reference,
            train_mse_difference=(aligned.training_mse-base.training_mse).mean(),
            validation_mse_difference=(aligned.validation_mse-base.validation_mse).mean(),
            validation_worse_month_fraction=(aligned.validation_mse>base.validation_mse).mean(),
            train_better_month_fraction=(aligned.training_mse<base.training_mse).mean()))
save('candidate_vs_frozen_validation',pd.DataFrame(comparison_rows))
# Recompute recorded validation losses from existing predictions, not model fits.
val_loss_errors=[]
for row in folds.itertuples():
    g=valid_pred.loc[valid_pred.holding_month.eq(row.holding_month)&valid_pred.excess_return.notna()]
    mse=float(np.mean((g.excess_return-g[f'{row.model}_{row.candidate}'])**2))
    val_loss_errors.append(abs(mse-row.validation_mse))
assert max(val_loss_errors)<1e-12

# 8. Endpoint prices and market calendars from existing RQData cache, no API.
needed_dates=set(pd.to_datetime(oos.entry_date))|set(pd.to_datetime(oos.exit_date))
quote_parts=[];calendar_dates=[]
for year in range(2022,2027):
    q=pd.read_parquet(ROOT/f'data/raw/rqdata/prices_{year}.parquet',columns=['close']).reset_index()
    calendar_dates.extend(q.date.unique())
    q=q.loc[q.date.isin(needed_dates)].copy()
    q['stock']=q.order_book_id.str.replace('.XSHG','.SH',regex=False).str.replace('.XSHE','.SZ',regex=False)
    quote_parts.append(q[['stock','date','close']])
quotes=pd.concat(quote_parts).set_index(['stock','date']).close
assert not quotes.index.duplicated().any()
source_price_errors={}
for endpoint in ['entry','exit']:
    dates=pd.to_datetime(oos[endpoint+'_date'])
    codes=oos.stock.copy()
    affected=codes.isin(['300114.SZ','302132.SZ'])
    codes.loc[affected&dates.ge('2025-02-17')]='302132.SZ'
    codes.loc[affected&dates.lt('2025-02-17')]='300114.SZ'
    index=pd.MultiIndex.from_arrays([codes,dates],names=['stock','date'])
    source=quotes.reindex(index).to_numpy()
    assert np.isfinite(source).all()
    err=np.max(np.abs(source-oos[endpoint+'_adj_close'].to_numpy()))
    source_price_errors[endpoint]=float(err)
    assert err<1e-10
calendar=pd.DatetimeIndex(sorted(set(calendar_dates)))
first=pd.Series(calendar,index=calendar.to_period('M')).groupby(level=0).min()
last=pd.Series(calendar,index=calendar.to_period('M')).groupby(level=0).max()
date_checks=[]
for month,g in oos.groupby('holding_month'):
    h=pd.Period(month,freq='M');r=g.iloc[0]
    assert g.formation_date.nunique()==g.entry_date.nunique()==g.exit_date.nunique()==1
    ok=(r.formation_date==last[h-1] and r.entry_date==first[h] and r.exit_date==first[h+1])
    date_checks.append(dict(holding_month=month,formation_date=r.formation_date,entry_date=r.entry_date,exit_date=r.exit_date,
        cached_calendar_matches=bool(ok),training_sample_end=r.training_sample_end,
        estimation_date=r.model_estimation_date,latest_training_label_date=r.training_last_label_available_date))
    assert ok
save('date_alignment_checks',pd.DataFrame(date_checks))
raw_error=float(np.max(np.abs(oos.exit_adj_close/oos.entry_adj_close-1-oos.actual_raw_return)))
target_error=float(np.max(np.abs(oos.actual_raw_return-oos.rf_return-oos.actual_excess_return)))
assert raw_error<1e-12 and target_error<1e-12
assert oos.training_last_label_available_date.le(oos.model_estimation_date).all()
assert oos.label_available_date.eq(oos.exit_date).all()
assert sha256(ROOT/'scripts/05_models.py')==run['script_sha256']
assert sha256(ROOT/'research_config.json')==run['config_sha256']

# Confirm the scope of model artifacts, rather than pretend networks were saved.
model_states=[str(p.relative_to(ROOT)) for p in (ROOT/'results').rglob('*') if p.suffix in {'.pt','.pth','.joblib','.pkl','.npz'}]
state=dict(no_model_refitting=True,no_hyperparameter_changes=True,no_test_period_changes=True,
    diagnostic_script_sha256=sha256(Path(__file__)),
    model_state_artifacts=model_states,linear_reconstruction_max_error=float(linear_checks.max_prediction_error.max()),
    source_price_max_abs_errors=source_price_errors,target_identity_max_abs_error=target_error,
    raw_return_identity_max_abs_error=raw_error,validation_mse_max_reconstruction_error=max(val_loss_errors),
    saved_sort_groups_verified=len(sort_checks),oos_rows=len(oos),months=36)

disp=monthly.groupby('model',sort=False).agg(mean_pred_sd=('pred_sd','mean'),min_pred_sd=('pred_sd','min'),max_pred_sd=('pred_sd','max'),
    min_unique=('unique_exact','min'),max_unique=('unique_exact','max'),largest_tie=('max_exact_tie','max'),
    d10_tie_split_months=('d10_boundary_split','sum'),max_d10_tie_return_range=('d10_tie_bound_width','max')).reset_index()
save('prediction_dispersion_summary',disp)
mechanism=pd.DataFrame(turnover_mechanism).groupby('year').agg(mean_rank_corr=('corr_with_negative_turnover','mean'),
    mean_d10_overlap=('d10_low_turnover_overlap','mean'),min_d10_overlap=('d10_low_turnover_overlap','min')).reset_index()
save('lasso_turnover_mechanism_yearly',mechanism)

# Formatting for the report; all numbers above come from saved inputs.
coef_display=matrix.reset_index();coef_display.columns=['feature','2023','2024','2025']
coef_display['nonzero_years']=matrix.abs().gt(1e-12).sum(axis=1).to_numpy()
ic_display=ic_summary[['period','model','months','mean_rank_ic','median_rank_ic','positive_ic_fraction']].copy()
decile_display=(100*mean_deciles).reset_index();decile_display.columns=['model']+[f'D{i}' for i in range(1,11)]
annual_prediction=prediction_annual.loc[prediction_annual.period.ne('2023-2025')].copy()
annual_prediction['oos_r2_pct']=100*annual_prediction.oos_r2
annual_prediction['rmse_pct']=100*annual_prediction.rmse
annual_prediction['mae_pct']=100*annual_prediction.mae
annual_port=portfolio_year.copy()
for col in ['annual_return','annual_volatility','max_drawdown','mean_one_way_turnover','mean_monthly_spread','synthetic_spread_annual_return']:
    annual_port[col+'_pct']=100*annual_port[col]
decomp_display=decomposition.loc[decomposition.period.eq('2023-2025')].copy()
for col in ['oos_r2','common_contribution_to_r2','cs_contribution_to_r2','centered_cs_r2','mean_prediction_only_r2']:
    decomp_display[col]*=100
disp_display=disp.copy()
for col in ['mean_pred_sd','min_pred_sd','max_pred_sd','max_d10_tie_return_range']:
    disp_display[col]*=100
boundary_display=monthly.loc[monthly.d10_boundary_split,['model','holding_month','d10_boundary_tie_group',
    'd10_boundary_selected','d10_boundary_excluded','d10_return_lower_tie_bound','d10_return_upper_tie_bound']].copy()
for col in ['d10_return_lower_tie_bound','d10_return_upper_tie_bound']:
    boundary_display[col]*=100
val_display=val_summary.loc[val_summary.model.isin(['RF','MLP','OLS'])].copy()
val_display['gap_in_pct_mse']=100*(val_display.validation_mse/val_display.train_mse-1)
worst=spread_months.loc[spread_months.model.eq('LASSO')].nsmallest(5,'spread').copy()
for col in ['d1','d10','spread','ew']:
    worst[col]*=100
selected_grid_gap=[]
for model in ['RF','MLP']:
    selected_grid_gap.append(model+': '+json.dumps(frozen['models'][model]['settings']))

report=f'''# ECO3080 — LASSO、预测排序与负多空收益的针对性诊断

诊断日期：2026-11-15。**仅分析已有系数、预测、配置、验证记录和回测结果；没有重训、重新调参、改变测试期或覆盖正式结果。** 诊断脚本为 `scripts/11_lasso_diagnostic.py`，详细计算另存 `reports/diagnostics/lasso/`。本报告不改变正式模型排名和论文主表。

## 结论先行：四类问题的区分

| 类别 | 本次判断 | 证据与边界 |
|---|---|---|
| 已确认的核心程序错误 | **未发现足以解释负D10−D1的目标符号、排序方向、端点对齐或线性截距错误** | 独立重建1440组的成员/等权收益；重建所有OLS/LASSO预测；全部17957条收益端点与缓存价格逐项核对 |
| 已确认的记录/展示缺陷 | 原并列诊断CSV只含唯一值数量；decile summary默认字符串序为D1、D10、D2…；配置中的primary_results_status仍为UNRUN | 与真实EXECUTED运行清单不同步。它们影响审计/阅读，不会翻转实际D1/D10或解释负收益；本轮不修改这些文件 |
| 模型设计与调参局限 | LASSO只保留2项、主要是低换手暴露；RF小网格且冻结深度3；MLP四候选把学习率/正则/epoch捆绑；参数选择按MSE而非IC或尾部收益 | 均是已确认的设计事实；不能仅凭预测分散度小就判定欠拟合 |
| 可能但尚未证实的问题 | 冻结RF欠拟合、MLP未收敛、特定行情暴露导致D1反弹更强、独立MLP反标准化数值缺陷 | 无RF/MLP拟合权重、逐epoch损失或分种子输出；本轮禁止重训，不能把这些可能性写成已确认错误 |
| 完全正常、应如实保留的实证结果 | 正平均Rank IC、正零基准OOS R²，可以与负D10−D1、不单调十分位收益并存 | 统计量的权重、基准和对尾部/波动的敏感性不同；年度模型排名也不稳定 |

## 1. LASSO：非零系数、大小及稳定性

非零判定同时检查精确不等于0和abs(beta)>1e−12，结论一致：**2023、2024、2025每年均为2个非零斜率，没有任何一年八个系数全部归零。** `-0.0`按零处理。

系数单位为“小数收益/一个[-1,1]排名单位”；某因子从−1变为+1的预测变化为2beta，不能将表中0.002直接读成0.002%。

{table(coef_display,{'2023':'{:.9f}','2024':'{:.9f}','2025':'{:.9f}'})}

{table(coef_summary[['year','nonzero_exact','intercept','turnover_abs_share','turnover_squared_share']],{'intercept':'{:.8f}','turnover_abs_share':'{:.2%}','turnover_squared_share':'{:.2%}'})}

**稳定的是主导的Turnover负系数，次要入选变量并不完全稳定**：2023保留ROA，2024–2025保留Size；不能因向量方向相近而声称所有因子选择稳定。支持集Jaccard和系数余弦见下表，二者回答不同问题。

{table(pd.DataFrame(stability),{'support_jaccard':'{:.4f}','cosine':'{:.6f}'})}

保存的LASSO排名几乎就是负Turnover的排名。以下只比较已有X和已有预测，不建立新的低换手策略，也不替换正式持仓。D10 overlap是现有LASSO D10与按已知Turnover最低排序得到同样人数集合的重合比例。

{table(mechanism,{'mean_rank_corr':'{:.6f}','mean_d10_overlap':'{:.2%}','min_d10_overlap':'{:.2%}'})}

LASSO预测横截面均值基本等于年度截距，因为每月rank特征均值接近0。截距接近训练Y均值是含截距回归与当月中心化X的正常结果，不是“把截距加了两次”。已按训练样本核对 b=mean(Y_train)−mean(X_train)·beta；误差最大为{coef_summary.intercept_identity_error.max():.3g}。

## 2. 预测分散度、精确并列与D10边界

原 `prediction_tie_diagnostics.csv` 实际只记录每月nunique，不能直接回答标准差或并列组大小。本轮从保存OOS预测重新计算，唯一值数量与该CSV全部一致。

下表标准差为**小数收益换成百分数后的标准差**（0.157表示约15.7bp），不是目标收益标准差。exact tie使用原始浮点值完全相等，与正式排序一致；另存round(6)唯一值供检查近似相等，但不据此重新分组。

{table(disp_display,{'mean_pred_sd':'{:.4f}','min_pred_sd':'{:.4f}','max_pred_sd':'{:.4f}','max_d10_tie_return_range':'{:.6f}'})}

只有相同预测值的组**横跨D9/D10切点**时，股票代码并列规则才可能改变D10成员。一个组内部并列但全部在D10内，不影响持仓集合。LASSO/OLS没有精确并列，因此不能用并列排序解释LASSO的表现。RF和MLP是否影响边界，以表中d10_tie_split_months为准，不能把“存在并列”自动说成“D10由代码决定”。

只有RF在2025-09出现一次D10边界被并列组跨越：5只并列股票中选2只、留3只，正式组按股票代码固定选择。下表是该期D10事后收益的并列边界范围（%）；区间宽约0.577个百分点。其余模型/月不存在这一D10成员歧义，MLP虽然偶有两个相同预测，但没有跨D10边界。因此这个局部敏感性不能解释四模型普遍负spread。

{table(boundary_display,{'d10_return_lower_tie_bound':'{:.5f}','d10_return_upper_tie_bound':'{:.5f}'})}

并列边界的收益上下界只是在已发生收益上计算可能的组员替换幅度，属于**事后审计边界**，不是可交易预测或优化信号。完整144个模型月的标准差、唯一数、最大组、边界内外数量见 `monthly_prediction_dispersion_ties_ic.csv`；月度精简表也放在附录。

## 3. 月度Spearman Rank IC

IC=同月预测与实际超额收益的Spearman相关，采用average ranks处理并列。所有模型每月使用相同股票；36个月汇总对月份等权，正IC比例为IC>0的月份数/月份数。由于每月rf是共同常数，改用实际Raw Return计算IC逐月完全相同。

{table(ic_display,{'mean_rank_ic':'{:.5f}','median_rank_ic':'{:.5f}','positive_ic_fraction':'{:.2%}'})}

这些平均IC为正，说明全横截面的平均秩关系并非完全反向；但不证明最高十分位在所有行情中都比最低十分位赚钱。Spearman使用所有股票的秩、对极端收益大小不敏感；D10−D1只看两端且直接承受极端收益。36个月IC均值也不给高波动月份更高权重，和pooled平方误差不同。

2025年LASSO平均IC仅0.00100，中位数−0.02747，四模型正IC月份均只有5/12。以上为描述统计，本轮没有对IC均值或年度差异另作显著性检验，“平均为正”不等于统计显著。

## 4. Decile Sorting代码与真实收益

正式代码在 `scripts/07_evaluate_backtest.py`：先按`[模型_pred, stock]`升序，再按`1+floor(position*10/N)`分组。**D1为最低预测，D10为最高预测**。每组人数最多差1；当N=497时D10有49只，这是固定分组公式的结果，不是漏选。

本轮用NumPy lexsort独立重建1440个模型/月/十分位组，成员与保存权重完全一致，等权正确，组间预测上下界有序；组收益与已保存decile_returns的最大绝对误差为{sort_checks.return_abs_error.max():.3g}。未发现倒排或把预测值当作真实回报的错误。

以下为36个月**平均月度真实Raw Return，单位%**，列按D1–D10数值顺序展示，不是各组CAGR：

{table(decile_display,{f'D{i}':'{:.4f}' for i in range(1,11)})}

所有模型的D10均不满足相对D1的平均收益优势，内部各组也非单调。这是实际排序收益的诊断结果，不应为得到单调性反转信号或重排十分位。

LASSO负spread最明显的五个**持有期**如下；不是普通月末到月末收益：

{table(worst[['holding_month','entry_date','exit_date','d1','d10','spread','ew']],{c:'{:.4f}' for c in ['d1','d10','spread','ew']})}

2024-09和2025-08的D1与D10都上涨，但D1涨幅更大，因而spread为负；不是D10必须亏钱。这个事实支持“尾部差异集中在若干强上涨持有期”的描述，但尚不能证明是某个因子或市场机制造成。

## 5. 分年度预测与组合：LASSO没有稳定领先

年度OOS R²仍用零预测分母，按该年共同股票月pooled计算；RMSE/MAE均为收益百分数。

{table(annual_prediction[['period','model','observations','oos_r2_pct','rmse_pct','mae_pct','r2_rank']],{c:'{:.4f}' for c in ['oos_r2_pct','rmse_pct','mae_pct']})}

**2023、2024的R²最高模型都是MLP，2025是LASSO。** 2023四模型R²都为负。不能把全期LASSO排名第一写成“每年都优于其他模型”。

下表是12个规定持有期的复合年收益、年化月波动、匹配rf的Sharpe、各年从1开始的MDD和实际漂移换手。2023平均换手排除初次建仓，2024/2025包含各自1月正常调仓。

{table(annual_port[['year','model','annual_return_pct','annual_volatility_pct','sharpe','max_drawdown_pct','mean_one_way_turnover_pct']],{c:'{:.3f}' for c in ['annual_return_pct','annual_volatility_pct','sharpe','max_drawdown_pct','mean_one_way_turnover_pct']})}

2023、2024 LASSO的D10在四模型中最高；2025为OLS最高，LASSO低于OLS和RF。因此LASSO既非预测端逐年稳定第一，也非组合端逐年稳定第一。

多空的“年收益”须区分口径。正式synthetic spread为每月D10−D1再复合，**不等于D10年复合收益减D1年复合收益**。下面同时列月均spread及其合成复合年收益；后者仍以单位多头减单位空头的归一化敞口展示，不是认证的可执行资金收益率。

{table(annual_port.loc[annual_port.model.isin(MODELS),['year','model','mean_monthly_spread_pct','synthetic_spread_annual_return_pct']],{'mean_monthly_spread_pct':'{:.4f}','synthetic_spread_annual_return_pct':'{:.3f}'})}

例如2024年LASSO D10年收益高于D1，但合成spread年收益仍为负；复合公式和波动路径不同，这本身不是记账错误。完整D1年收益也保存在 `portfolio_by_year.csv`。

## 6. RF/MLP：验证记录支持哪些拟合判断

只使用冻结日真正可见的23个验证月诊断候选设置，2022-12仍不参与参数选择。288条已保存验证fold的MSE均从既有验证预测重新计算，最大误差{max(val_loss_errors):.3g}；没有调用fit。训练MSE与验证MSE均为原始小数收益平方单位，mean_gap为按月平均差。

{table(val_display[['model','candidate','frozen_selected','train_mse','validation_mse','mean_gap','gap_in_pct_mse']],{'train_mse':'{:.8f}','validation_mse':'{:.8f}','mean_gap':'{:+.8f}','gap_in_pct_mse':'{:+.3f}'})}

冻结配置：`{selected_grid_gap[0]}`；`{selected_grid_gap[1]}`。

RF较深候选降低训练误差，却没有改善这23个月验证MSE，存在**候选配置层面的过拟合迹象**；冻结选择较浅depth=3是验证结果，并非程序误选。但这不能证明冻结RF已充分拟合，也不能从深度浅直接宣称欠拟合。RF只试了3组联合配置，max_features固定为浮点数1.0（每次分裂考虑全部8个特征，并非整数1所指的单个特征），优化空间有限；没有保存实际树深度/叶子分布，不能检查最终每棵树。

MLP候选0/2的训练MSE较低但验证较差；候选3更强正则、较低学习率、120个全批次epoch的验证MSE最好，表现符合偏差/方差取舍。四候选不是完整独立网格：60epoch同时对应lr=.003、weight_decay=.001，120epoch同时对应lr=.001、weight_decay=.01，不能将差异单独归因于epoch或正则。没有逐epoch损失/梯度、收敛诊断或各seed输出，**不能确认“120epoch不足”或“网络已经收敛”**。

冻结MLP的平均训练MSE甚至略高于OLS（0.016438对0.016426），可能与正则偏差或有限优化步数有关；但其验证MSE较低。这个事实是优化/容量诊断的线索，不构成已证实的程序错误，也不足以单独证明欠拟合。这里没有保存的网络权重可进一步定位。

训练与验证处于不同市场月份，原始MSE受行情波动水平影响；简单train/validation gap不是纯过拟合量。更可信的是相同fold中候选相对冻结配置的配对差，见 `candidate_vs_frozen_validation.csv`。测试表现不用于重新选择配置，本报告也不提出“用测试最好的候选替换正式模型”。

## 7. 共同收益水平与横截面选股能力的分解

令同月真实均值mu_t、预测均值m_t，去均值部分为y~和p~。有精确恒等式：

`Σ_i(y_i−p_i)² = N_t(mu_t−m_t)² + Σ_i(y~_i−p~_i)²`。

零预测分母同样分为`N_t mu_t² + Σ_i y~_i²`。将收益改善分别除以原始零预测分母，可得到common contribution和cross-sectional contribution，两者相加**恰好**等于原始OOS R²。

下表各R²/贡献为百分数或百分点。`centered_cs_r2`=1−Σ(y~−p~)²/Σy~²，属于**事后横截面评价**；真实当月均值只用于分析实现后的误差，绝未生成信号、调整持仓或重训模型。`mean_prediction_only_r2`只是保留现有预测的当月均值时的误差分解参照，不是新增正式模型。

{table(decomp_display[['model','oos_r2','common_contribution_to_r2','cs_contribution_to_r2','centered_cs_r2','mean_prediction_only_r2']],{c:'{:.5f}' for c in ['oos_r2','common_contribution_to_r2','cs_contribution_to_r2','centered_cs_r2','mean_prediction_only_r2']})}

**四模型相对零预测的正R²，均来自共同收益水平项；横截面贡献均为负。** LASSO的优势主要是将横截面预测压缩，使这部分损失比OLS小，而非证明它在绝对意义上已优于同月横截面均值参照。OLS和LASSO的共同均值贡献几乎相同，也符合两者相同训练样本、rank-X均值近0和截距接近历史均值的事实。

四模型centered_cs_r2为负，与平均Rank IC为正不矛盾：平方误差受预测幅度校准、收益极值与高波动月份支配；Rank IC对股票收益数值大小不敏感，并对各月等权。D10−D1进一步只看尾部。本样本中2024-09、2025-08等月份的负尾部差异足以破坏全期排序组合；不需要假设代码倒排来解释。

这不是把未来mu_t用于可交易benchmark的建议，也不是将当月实际均值加入X。它只是回答“现有正零基准R²主要在预测什么”。各年分解已单独保存，不能把全期分解当作未来规律。

## 8. 目标符号、时点、截距和反标准化检查

| 检查 | 实际结果 | 可确认程度 |
|---|---|---|
| 原始收益方向 | 所有测试行均为Exit/Entry−1；最大误差{raw_error:.3g} | 未发现负号/价格倒置 |
| 超额收益方向 | 所有行均为Raw−rf；最大误差{target_error:.3g} | 未发现减法倒置或减CSI500 |
| 源价格端点 | 与已有RQData缓存逐行核对，Entry最大差{source_price_errors['entry']:.3g}、Exit最大差{source_price_errors['exit']:.3g} | 包括300114→302132同股代码延续 |
| 市场日期 | 36个月Formation/Entry/Exit均与缓存市场交易日首末日相符 | 未见普通月末收益替代规定持有期 |
| 标签可用性 | 所有训练最新标签日期不晚于估计日；label_available_date=Exit | 未见年度边界标签穿越 |
| 排序方向 | 1440组成员/等权/收益一致；D10预测最高 | 未见颠倒 |
| OLS/LASSO截距 | 对全部测试行用保存beta和b重建；最大预测误差{linear_checks.max_prediction_error.max():.3g} | 未见漏加、重复加或单位缩放 |
| MLP反标准化代码 | 训练仅用训练Y均值/标准差，输出为mean(seed outputs)×train_sd+train_mean，且源码SHA匹配运行清单 | 公式正确，保存预测量级未见100倍错误；无网络权重，不能独立逐网络数值核验 |

RF/MLP并未保存`.pt/.pth/.joblib`等拟合状态文件，已保存的是最终预测、配置、MSE和线性系数。这个归档缺口限制模型内部诊断，不应假装本轮检查过未保存的权重。没有为补齐权重而违反本次“不重训”的要求。

## 9. 可以写入论文的诊断结论

1. LASSO不是退化为全零斜率的常数模型，三年均保留2项，预测排序几乎由低换手暴露决定；截距解释共同收益水平，不能解释D1/D10成员差异。
2. 现有负多空收益没有被发现是排序/符号/时点错误，LASSO也不受精确并列规则影响；RF/MLP边界并列影响已量化，不能泛化为全样本问题。
3. 正平均Rank IC与负多空收益并存，且2025的尾部相对收益转弱。全期模型排名不是逐年稳定排名。
4. 零基准R²的改善主要来自共同收益水平；LASSO减少了较差的横截面幅度预测损失。这比“LASSO已成功预测横截面股票收益”更符合本次证据。
5. RF/MLP部分更灵活候选呈现训练改善、验证变差；冻结模型是否欠拟合/MLP是否未收敛仍缺证据。不能为使非线性模型胜出而事后改变网格、目标、样本或组合。

## 附录：各月预测分散度与并列

下面sd为百分数，split表示D10边界被精确并列组跨越。完整原始小数、实际收益边界及IC在配套CSV中。
'''
for model in MODELS:
    d=monthly.loc[monthly.model.eq(model),['holding_month','stocks','pred_sd','unique_exact','max_exact_tie','d10_boundary_split']].copy()
    d.pred_sd*=100
    report+='\n### '+model+'\n\n'+table(d,{'pred_sd':'{:.5f}'})+'\n'

after={str(p.relative_to(ROOT)):dict(sha256=sha256(p),mtime_ns=p.stat().st_mtime_ns) for p in protected}
assert before==after,'A protected official artifact changed during diagnostics.'
state['protected_files_unchanged']=len(protected)
state['all_protected_hashes_and_mtimes_unchanged']=True
(OUT/'diagnostic_manifest.json').write_text(json.dumps(state,ensure_ascii=False,indent=2))
(OUT/'protected_artifacts_before_after.json').write_text(json.dumps(before,ensure_ascii=False,indent=2))
report+=f'\n正式结果保护：本轮核对{len(protected)}个已有产物/配置/代码/Notebook，前后SHA-256与mtime均一致。\n'
(ROOT/'reports/lasso_diagnostic.md').write_text(report)
print(json.dumps(state,ensure_ascii=False,indent=2))
print('\nRank IC summary\n',ic_summary.to_string(index=False))
print('\nPrediction dispersion\n',disp.to_string(index=False))
print('\nFull-period decomposition\n',decomp_display.to_string(index=False))
