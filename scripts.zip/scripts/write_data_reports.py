"""Write data reports using the actually executed audit artifacts."""
import json
import pandas as pd
from common import ROOT,AUDIT,md_table

s=json.loads((AUDIT/'audit_summary.json').read_text())
p=json.loads((AUDIT/'panel_summary.json').read_text())
inv=pd.read_csv(AUDIT/'pkl_inventory.csv').fillna('')
csv=pd.read_csv(AUDIT/'csv_inventory.csv').fillna('')
files=pd.read_csv(AUDIT/'original_file_manifest.csv')
zipinfo=pd.read_csv(AUDIT/'zip_members.csv').fillna('')
view=inv[['filename','date_start','date_end','frequency','stocks','missing_share']].copy()
view['missing_share']=(pd.to_numeric(view.missing_share)*100).round(3)
view.columns=['Dataset','Start','End','Frequency','Stocks','Missing %']
view['Source']='User-supplied local PKL; provider metadata initially absent'
view['Usable?']='PARTIALLY VERIFIED'
view.loc[view.Dataset.str.contains('book_to_market|ep_ratio|return_on_asset|return_on_equity|net_profit|earnings_per_share'),'Usable?']='REQUIRES PIT VERIFICATION'
view.loc[view.Dataset.eq('ind_code.pkl'),'Usable?']='VERIFIED structure; outside eight predictors'
view.loc[view.Dataset.eq('zz800_close_daily.pkl'),'Usable?']='UNUSABLE as CSI500 benchmark/target'

report=f'''# ECO3080 — Complete Data Audit

审计日期：2026-11-15（Asia/Shanghai）。正式规范：`完整版proposal.pdf`，完整阅读6页，已提取全文并渲染关键公式/变量页。两份完整版 PDF 的 SHA-256 相同。旧 `RESEARCH_SCOPE_AUDIT.md` 的三模型、Top20%、早期OOS设计已经被正式 Proposal 替代。

## 1. Inventory and audit method

原始文件共 **{s['original_files']}** 个，合计 **{s['total_original_bytes']:,} bytes**，包括 **{s['pkl_files']} PKL、{s['zip_files']} ZIP**。审计逐个读取大表，未同时载入所有大型对象。原始文件从未覆写、移动或删除；完整 SHA-256、大小、路径、修改时间见 `audit/original_file_manifest.csv`。

ZIP 全部遍历并校验可读内容，成员目录、解压位置、与已有文件的逐字节哈希匹配见 `audit/zip_members.csv`。拒绝绝对路径、`..`、反斜杠路径和符号链接；仅将尚不存在的 CSV/字典解压到各自的 `data/raw/csmar/<archive>/`。保留所有原始ZIP。附加 merge ZIP 的有效 CSV 与项目文件完全重复，不重复解压；macOS 元数据不作为数据。

PKL 来源限定为用户明确交付的本地研究文件，使用仅允许必要 pandas/NumPy 数据恢复对象的 restricted unpickler，不接受任意 Python globals 或外部 persistent objects。记录 object type、shape、索引、列结构、真实日期、频率、缺失、重复、内存及分布；详见 `audit/pkl_inventory.csv`、`audit/pkl_details.json`。所有 PKL 均成功读取。布尔状态整行相同不是重复日期；真正的重复键分别检查 index/columns。

## 2. Data Inventory Table

以下 Missing % 是全表缺失率，包含未上市年份，不等同于CSI500池内缺失率；池内结果见后续面板报告。

{md_table(view)}

CSV 共检查 **{s['csv_files_inspected']}** 份（含ZIP新增分片及逐字节重复副本）。每份的实际列名、日期范围、行数、候选键、重复和缺失见 `audit/csv_inventory.csv`、`audit/csv_details.json`。证券代码使用字符串，保留前导零。日频数据按标签对齐，不能按列位置合并。

## 3. Available and Verified Data

- 后复权价格实际覆盖2001-01-02至2026-06-30，早于初始Momentum所需2008-12；包含2026年1、2月首个交易日。`20260630` 是快照标记，不是样本起点。
- 每日历史成员覆盖2007-01-15至2025-03-31，4425个日期每次均500只。2025年4–12月补充CSV有4500行，9个月、每月500只、无重复；来源更新时间不晚于形成日且间隔不超过7天。其历史来源进一步通过RQData核验，不能因500只就自动认证。
- CSMAR `TRD_Nrrate` 完整版有5877个连续自然日，2010-01-01至2026-02-02；有真实利率及单位字典。另一个同名数据只有日期和基准代码，**没有数值**，不能用于超额收益。当前完整利率是NRI01一年期存款代理，不是SHIBOR。
- 停牌、ST、涨停、跌停及新股标志均实际存在。日涨跌停ZIP虽然名为“日个股回报率文件”，实际只含 `Stkcd, Trddt, LimitStatus`，**没有日收益或价格**。其与PKL重叠端点的涨跌停状态零冲突，见 `audit/limit_flag_crosscheck.csv`。

## 4. Available but Problematic Data

- 月度mask只到2024-10；与每日名单在42个早期月份有证券代码差异：2007–2008年 `000043/001914`，2009-01至2010-06 `000022/001872`。每月均500只掩盖了历史代码处理差别。审计面板优先保留每日名单当时的代码，记录来源并等待RQData核对；不把两个代码当作两只股票增加样本。
- 已有 `csi500_stock_month.csv` 实际仅92000行、形成月2009-12至2025-03，未包含额外9个月名单；Notebook宣称完整2025年与文件事实不一致。
- 原Notebook仅5因子，缺少正式财务三因子；训练使用 holding_month 比较而非 label_available_date，验证期也未扩展逐月重估。其随机early stopping、近似零rf的Sharpe、忽略期初净值的MDD及RF调参与测试树数不一致，均需要重建。Notebook中已有数字未被本次采纳。
- 新股flag为object，约49.4%缺失，按deep memory统计约1.15 GiB；未知状态不能当False。ST/停牌表对部分无历史证券是NaN；某些注销后列仍显示False，需结合证券存续和原始价格检查。
- 原始收益有极端值及退出端点缺失；不能按涨跌事后删除或填0。代码变更300114→302132已由公司公告核验：2025-02-17起持股数量不变，历史应用价格按同一证券连续连接；这是标识清洗，不是用另一个日期的价格代替规定端点。

## 5. Missing Data

- 项目原始文件中没有 `shibor_rates.pkl`。已有人民币利率代理可匹配持有期；SHIBOR是否需要补充由RQData权限及官方口径核验决定，避免无必要重复下载。
- 本地财务文件没有2008–2009年历史报表，且没有原始版本链；无法独立支持2010年初的PIT重建。
- 原始财务PKL没有公告日、报告期、版本说明或attrs；只有返回过去日期的值不足以证明PIT。现有CSMAR报表需原始披露版本/更正历史，或由可信RQData PIT接口替代并交叉核对。
- 严格执行回测还缺买卖盘排队与订单成交资料；状态可做保守可交易性检验，不能证明所有收盘订单一定成交。做空库存与借券费率也未完整观测。

## 6. Data Requiring Additional Verification

财务变量定义（尤其RQData BM使用账面权益TTM平均，CSMAR ROA分母另有定义）、A股市值与总市值、换手率单位、复权价格股息/公司行为处理，以及历史成员来源和退市/吸收合并终值，均须逐项核对。不能静默将财务指标滞后一个月冒充PIT。

CSMAR官方财务报表手册（本次下载，`data/raw/csmar/financial_statements_manual_20260921.pdf`）PDF第15页明确指出历史财务数据会被后来更正覆盖；现有导出缺 `IfCorrect, DeclareDate`。第18页列出这两个字段。`Financial Data Before and After Correction`（Accounting Error Correction库）的当前学校会话显示No Permission，未下载受限数据、未绕过权限。RQData核验进展及后续替代方案单列在 `02_rqdata_completion.md`。

## 7. Audit artifacts

- 全部原始文件/重复组：`audit/original_file_manifest.csv`、`audit/audit_summary.json`
- ZIP成员与哈希去重：`audit/zip_members.csv`
- PKL逐文件完整结构和分布：`audit/pkl_inventory.csv`、`audit/pkl_details.json`
- CSV逐文件结构和缺失：`audit/csv_inventory.csv`、`audit/csv_details.json`
- 历史名单重叠：`audit/membership_overlap.csv`
- 价格人工计算：`audit/manual_price_checks.csv`
- 与旧面板的重新计算对照：`audit/prior_panel_crosscheck.csv`

本报告只证明实际检查得到的事实；正式Data Ready状态以最新 `03_data_readiness.md` 和 `data/processed/data_status.json` 为准。
'''
(ROOT/'reports/01_data_audit.md').write_text(report)
print('Wrote reports/01_data_audit.md')

status_path=ROOT/'data/processed/data_status.json'
status=json.loads(status_path.read_text())
if status['formal_data_ready']:
    panel=pd.read_parquet(ROOT/'data/processed/panel_monthly.parquet')
    eligible=panel.loc[panel.eligible_at_formation]
    fs=status['features']
    factors=pd.read_csv(AUDIT/'rqdata_factor_crosscheck.csv')
    lineage=[]
    for path in sorted((ROOT/'data/raw/rqdata').glob('*.parquet')):
        import pyarrow.parquet as pq
        meta=pq.read_metadata(path)
        lineage.append(dict(file=str(path.relative_to(ROOT)),bytes=path.stat().st_size,rows=meta.num_rows))
    pd.DataFrame(lineage).to_csv(AUDIT/'rqdata_cache_inventory.csv',index=False)
    manifest=(ROOT/'data/raw/rqdata/collection_manifest.jsonl').read_text().splitlines()
    rq=f'''# RQData Environment Verification and Missing-Data Completion

2026-11-15，使用用户指定的现有RiceQuant Python，不重新安装RQSDK、不申请或重置License、不修改配置。`rqdatac.init()`及000001.XSHE在2026-10-12至16的查询实际成功。RQData版本3.8.1、Python3.12.14；原有quant环境也已验证可运行pandas/NumPy、scikit-learn、statsmodels、PyTorch和Arrow。模型使用`/opt/anaconda3/envs/quant/bin/python`。提取端只在进程内追加quant现有site-packages来调用Arrow写Parquet，没有安装或更新RiceQuant依赖。为绕过pandas旧Arrow扩展注册兼容问题，直接使用Arrow Table写文件。

默认受限网络的第一次init出现gaierror；使用已授权的网络执行权限后成功，非许可证失效。日志不包含License、密码或令牌。

## 实际获取的数据

`data/raw/rqdata/`现有 **{len(lineage)}** 份Parquet，约 **{sum(x['bytes'] for x in lineage)/2**20:.1f} MiB**。逐次参数、字段、返回行数和上海时间下载时间见`collection_manifest.jsonl`；小规模能力测试见`probe_manifest.json`；缓存文件清单见`reports/audit/rqdata_cache_inventory.csv`。已缓存的请求不重复下载。

| 用途 | 接口及实际内容 | 覆盖和决策 |
|---|---|---|
| 历史股票池 | index_components，显式formation date，000905.XSHG | 193个月，2009-12至2025-12，每月500只，作为最终成员来源 |
| PIT特征 | get_all_factor_names后调用get_factor | 每个形成日的BM TTM、EP TTM、ROA TTM、A股市值、总市值；使用新PIT财务值，保留旧值作审计 |
| 财报版本 | get_pit_financials_ex(date=历史日期, statements=all) | 2009、2015、2022、2025年末，三个预定样本股票、三大表相关字段；84项公式及时间检查 |
| 价格 | get_price(post, skip_suspended=False) | 2008-12至2026-02-02，按年仅请求研究所需历史证券，统一新的后复权数据版本 |
| 公司行为 | get_ex_factor，抽样none/post报价 | 验证股息/拆分影响；后复权比例作为Proposal要求的调整收益代理，不宣称等于逐笔现金分红到账账本 |
| 换手率 | get_turnover_rate(today) | 三只股票2022-12核对，与本地值一致；单位为百分数，统一倍数不改变排名 |
| 利率 | get_interbank_offered_rate(ON,1M) | 2009-12至2026-02-02；用于1M SHIBOR代理的Sharpe敏感性，主目标保留已有CSMAR NRI01代理 |

## 重叠核验与来源选择

{md_table(factors[['variable','overlap','max_abs_difference','differing_gt1e_8']])}

本地BM与RQData重叠一致；EP和ROA各6个值不同。因此正式三财务特征全部使用新缓存的RQData历史PIT值，不对个别结果挑选来源。A股市值在96496个可比较成员记录上一致；Size保留ln(A股总市值)，未改成流通市值或公司总市值。BM/EP分母则按供应商定义使用公司总市值，二者不能混称同一字段。

抽样旧后复权价最大差异超出四位小数舍入：600004在2013-11-13、000006在2015-07-17、600066在2013-11-13。对应不复权价相差0.01元，说明差异来自历史收盘报价版本，不是简单前后复权比例混用。完整差异表见`raw_price_vintage_differences.csv`；最终价格统一刷新，不把未验证来源随机拼接。原始PKL完整保留。

历史名单只有形成月2009-12、2010-01、2010-02与每日本地名单不同：RQData为600849，本地为601607。正式池采用显式历史查询返回的600849；当前RQData证券行情接口不识别该历史代码，本地也无该价格列，3条记录按事前最低历史要求不合格，不改用后来代码冒充历史证券。这个小数据缺口须披露，不能宣称所有历史成员行情完整无缺。

## PIT及字段定义

RQData官方文档明确说明原生/衍生财务字段按公布及修订的历史时点处理；`get_pit_financials_ex`的历史date限制可见记录。`if_adjusted`区分当期/非当期披露，绝不是“是否更正”标记。`rice_create_tm`为供应商入库时间，历史重建可能晚于原公告；本研究的as-of依据为info_date与供应商PIT契约，不宣称当年数据库已实际交付这些行。

抽样使用当时info_date不晚于查询日的每季最新可见版本，利润TTM按当前累计+上年全年−上年同期累计、资产/权益TTM按最近4个季末平均重算。再用相应分子分母核对BM、EP、ROA；84项检查最大相对误差为{status['max_pit_formula_relative_error']:.3g}。没有用最终更正值配最早公告日。

本研究使用的供应商定义为：BM=权益TTM平均/总市值；EP=归母利润TTM/总市值；ROA=净利润TTM/资产TTM平均。它们与CSMAR F050204C的平均期末/上年同期资产分母并不相同，因此不混用。正式Proposal只规定形成日可得BM/EP/ROA，本项目将上述原有文件对应的TTM口径固定并在论文明确。

官方依据：[RQData A股PIT及因子文档](https://www.ricequant.com/doc/rqdata/python/stock-mod)、[RQData货币市场接口](https://www.ricequant.com/doc/rqdata/python/repo)、[SHIBOR规则与ACT/360说明](https://www.shibor.sh.cn/chinese/bkshibor/)。API原始返回与公式核对表已留在本地，可脱离网络复查。

## CSMAR补充情况

此前确实取得官方Financial Statements手册，并观察到Accounting Error Correction下Financial Restatement Announcement和Financial Data Before and After Correction均No Permission；未取得更正数据。RQData现已提供所需历史版本路径，无需继续请求CSMAR购买/越权。若复核RQData仍有疑问，手动路径为：CSMAR → Search → Accounting Error Correction → Correction Track → Financial Data Before and After Correction；所需字段为证券代码、被更正会计年度/期间、报表类型、科目代码、原错误公告日、更正公告日、更正序列、更正前金额、更正后金额。范围2007–2026，研究历史成员；必须由已有合法权限的用户下载。主数据现在不依赖这个不可访问表。
'''
    (ROOT/'reports/02_rqdata_completion.md').write_text(rq)
    missing=pd.DataFrame([
        ['Historical CSI500','Complete','193 explicit-date API lists; 500 members each'],
        ['Stock returns','Partially Complete','All eligible test/application labels present; 6 earlier eligible missing labels'],
        ['Momentum/Reversal','Complete for eligible sample','2008-12 warmup; exact month-end endpoints'],
        ['BM/EP/ROA PIT','Complete for main analysis','RQData historical PIT factor contract + raw version/formula checks'],
        ['Size/Turnover','Complete for eligible sample','A-share capitalization; turnover percent; overlap verified'],
        ['Volatility','Complete for eligible sample','21 valid daily adjusted returns, sample standard deviation'],
        ['Risk-free holding return','Complete proxy','CSMAR NRI01 365 compounding; SHIBOR1M robustness'],
        ['Trading restrictions','Partially Complete','ST/suspension/limits observed; actual order fills and borrowing costs absent']],
        columns=['Requirement','Status','Evidence / limitation'])
    missing.to_csv(AUDIT/'missing_data_checklist.csv',index=False)
    readiness=f'''# Data Readiness Decision

**READY_WITH_DISCLOSED_LIMITATIONS：可以运行正式八因子预测及理论组合比较。** 这不是“所有历史证券行情完整、所有交易可执行”的认证。机器可读门槛：`data/processed/data_status.json`。

{md_table(missing)}

关键PIT阻碍已由RQData补充并核验解除。股票池为193个实际历史查询的500只成员；入样筛选只依赖形成时X、ST、停牌及成交额，不看未来Y。股票后续退出指数不会被删除。

3条600849的历史价格缺口仅在形成时按最低历史规则排除。另有6条形成时合格但退出标签缺失的训练/验证观测，明确保留在面板，估计/损失评价时剔除并量化。它们涉及吸收合并等证券事件，未伪造现金或换股终值；训练样本仍有少量非随机缺失风险。测试期每个形成时合格股票都有真实调整收益端点，故无需按事后收益删股；2026-01同样完整。

主无风险代理NRI01不是无信用风险的国债，也不是一个月期限的市场投资工具；按实际持有日数匹配收益，但不声称解决期限匹配/可投资性。SHIBOR1M为独立利率敏感性。两者都不作为预测X使用。

组合主结果明确为理论sorting returns。可观察停牌/涨跌停用于逐模型量化成交障碍；不以状态阳性股票事后删改主排名，也不声称观察到了订单成交。成本检验为预设假设成本，不能称为观测净收益。D10-D1是单位多头减单位空头的合成序列，忽略借券和保证金融资。

超参数网格、随机种子、最低历史和HAC lag在训练前固定于`research_config.json`。2022-12验证收益在冻结日尚不可见，故只有2021-01至2022-11共23个月可参与冻结；2022-12仅作描述。测试期按年重估，且每次都检验label_available_date<=estimation_date。
'''
    (ROOT/'reports/03_data_readiness.md').write_text(readiness)
    (ROOT/'reports/02_data_readiness.md').write_text(readiness)
    coverage=pd.read_csv(AUDIT/'final_monthly_coverage.csv')
    raw_missing=pd.DataFrame([dict(feature=f,eligible_missing=int(eligible[f+'_raw'].isna().sum()),
                                   eligible_missing_pct=100*eligible[f+'_raw'].isna().mean()) for f in fs])
    raw_missing.to_csv(ROOT/'results/tables/feature_coverage.csv',index=False)
    validation=f'''# Stock-Month Panel Validation

`data/processed/panel_monthly.parquet`：{len(panel):,}条历史成员记录、193个持有月（2010-01–2026-01）。每月原始成员500只，证券/形成月键唯一。形成时合格{len(eligible):,}条，月数量范围{int(coverage.eligible.min())}–{int(coverage.eligible.max())}，均值{coverage.eligible.mean():.2f}。末尾独立2026-01应用497只合格股票，不进入36个月主测试。

{md_table(raw_missing)}

## 固定构造规则

- Formation为全市场最后交易日；Entry为下一月全市场第一个交易日收盘；Exit为再下一月第一个交易日收盘；label_available_date=Exit。价格按严格日期取值，不寻找股票后来实际交易日。
- R=Exit后复权价格/Entry后复权价格−1，Y=R−同持有期rf。主rf按NRI01年利率每日log复利，365basis，累计区间[Entry,Exit)，共(Exit−Entry)个自然日；用年率精确计算，避免导出的日利率舍入。
- Momentum=P(t−1)/P(t−12)−1；Reversal=−[P(t)/P(t−1)−1]。Turnover为21个交易日today换手率均值，Volatility为同21日调整收益样本标准差（ddof=1），缺价格不forward fill后再计算收益。
- 最低历史：最近252个市场日均有价格、Momentum/Reversal端点为正、换手和日收益均有21个有效值。形成时已知非ST、非停牌、成交额>0。新股标志定义不明确，未以它另行增加年限阈值。
- 每因子每月在全部形成时合格股票中计算average rank，2(rank−1)/(有效N−1)−1，偶发缺失填0。先定X及排名，再判断未来Y可评价性；整个因子月均缺失时断言停止。原值、未核验旧财务值、规范化值均保留。
- 形成月、持有月、日期、源成员代码、有效代码、数据源、市场状态、原始/超额收益和所有cutoff均可追踪。

## 实际核验与缺失处理

初始三个股票月已逐个对价格端点、Momentum回看日期手算，见`audit/manual_price_checks.csv`。与已有92000行面板重算结果已保存`prior_panel_crosscheck.csv`；刷新价格后产生的细微差异保留为数据版本变化，不追求复制旧Notebook中的结果。

300114→302132的代码变更于2025-02-17生效、持股数量不变，依据[公司在交易所披露的公告](https://disc.static.szse.cn/download/disc/disk03/finalpage/2025-02-07/e2d8b9d3-879b-4587-9e1e-235ebf4c8a44.PDF)。使用同一证券连续价格/状态历史；保留形成时证券代码。这修复2025-02持有期原先的退出价格缺失，不将别的交易日期代替退出日。

所有剩余缺失Y和超过100%绝对持有期收益分别列于`missing_return_labels.csv`、`extreme_return_labels.csv`。大涨大跌未截尾；停牌可能仍有报价，不能按报价非空就认定可成交。股票代码600849的缺行情在形成时已量化，6条更早合格样本缺退出标签在估计时明确排除；未填0。

## 结果前检查

八特征、同一Target、相同有效训练/评价观测共享；无stock/date哑变量或额外因子。所有X信息截止不晚于formation，formation<Entry<Exit。测试期原始成员18000条，形成时合格17957条且Y均完整；应用原始500条、合格497条且Y均完整。OLS以NumPy最小二乘独立核对，预测最大差异见`audit/ols_numerical_check.json`。

本次采用供应商按公开公告重建的历史as-of信息，不证明当年数据供应系统已及时送达。理论调整价格收益也不等于含税费、实际分红支付时点的可成交现金账本；正式论文需保留这些限制。
'''
    (ROOT/'reports/04_panel_validation.md').write_text(validation)
    (ROOT/'reports/03_panel_validation.md').write_text(validation)
    print('Wrote RQData completion, readiness and panel-validation reports')
