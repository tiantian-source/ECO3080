"""Cache only missing research observations using the configured RQData SDK."""
import sys,json,inspect
from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo
import rqdatac
import pandas as pd
sys.path.append('/opt/anaconda3/envs/quant/lib/python3.12/site-packages')
import pyarrow as pa
import pyarrow.parquet as pq

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'data/raw/rqdata'
OUT.mkdir(parents=True,exist_ok=True)
rqdatac.init()
panel=pq.read_table(ROOT/'data/processed/panel_monthly.parquet').to_pandas()
calls=[]

def cache(name,fn,**parameters):
    path=OUT/(name+'.parquet')
    if path.exists():
        return pq.read_table(path).to_pandas()
    data=fn(**parameters)
    if isinstance(data,list):
        data=pd.DataFrame({'order_book_id':data})
    if data is None or len(data)==0:
        data=pd.DataFrame()
    pq.write_table(pa.Table.from_pandas(data),path)
    calls.append(dict(file=name+'.parquet',function=fn.__name__,parameters=parameters,
                      rows=len(data),columns=list(data.columns),
                      retrieved_at=datetime.now(ZoneInfo('Asia/Shanghai')).isoformat()))
    with (OUT/'collection_manifest.jsonl').open('a') as stream:
        stream.write(json.dumps(calls[-1],ensure_ascii=False,default=str)+'\n')
    return data

def to_rq(stock):
    return stock.replace('.SH','.XSHG').replace('.SZ','.XSHE')

factors=['book_to_market_ratio_ttm','ep_ratio_ttm','return_on_asset_net_profit_ttm',
         'a_share_market_val_3','market_cap_3']
names=set(pq.read_table(OUT/'factor_names.parquet').to_pandas().value)
assert set(factors)<=names
all_members=[]
for number,(month,group) in enumerate(panel.groupby('formation_month',sort=True)):
    date=str(group.formation_date.iloc[0].date())
    members=cache('members_'+month,rqdatac.index_components,order_book_id='000905.XSHG',date=date)
    assert len(members)==500 and members.order_book_id.nunique()==500
    members=members.copy()
    members['formation_month']=month
    members['formation_date']=date
    all_members.append(members)
    # Query actual effective members from the API, not a current list backfill.
    cache('financial_'+month,rqdatac.get_factor,order_book_ids=members.order_book_id.tolist(),
          factor=factors,start_date=date,end_date=date)
    if number%12==0:
        print('Cached members and five documented factors:',month,flush=True)
pq.write_table(pa.Table.from_pandas(pd.concat(all_members,ignore_index=True)),OUT/'membership_monthly.parquet')

# Historical as-of raw disclosures substantiate the documented factor PIT rule.
# Small, predefined crosschecks cover early/middle/late periods and all eight
# quarterly input observations needed for a trailing calculation.
for date,start,end in [('2009-12-31','2007q1','2009q4'),
                       ('2015-12-31','2013q1','2015q4'),
                       ('2022-12-30','2020q1','2022q4'),
                       ('2025-12-31','2023q1','2025q4')]:
    sample=['600004.XSHG','000006.XSHE','600066.XSHG']
    d=cache('pit_asof_'+date,rqdatac.get_pit_financials_ex,order_book_ids=sample,
          fields=['net_profit','net_profit_parent_company','total_assets','equity_parent_company'],
          start_quarter=start,end_quarter=end,date=date,statements='all')
    assert pd.to_datetime(d.info_date).le(pd.Timestamp(date)).all()
    cache('factor_inputs_'+date,rqdatac.get_factor,order_book_ids=sample,
          factor=['book_to_market_ratio_ttm','ep_ratio_ttm','return_on_asset_net_profit_ttm',
                  'net_profit_ttm_0','total_assets_ttm_0','net_profit_parent_company_ttm_0',
                  'equity_parent_company_ttm_0','market_cap_3'],start_date=date,end_date=date)

# Reuse existing matched RMB proxy as primary; obtain SHIBOR for documented
# alternative risk-free robustness, not as an extra model feature.
cache('shibor_200912_202602',rqdatac.get_interbank_offered_rate,
      start_date='2009-12-01',end_date='2026-02-02',fields=['ON','1M'])
for code in ['600004.XSHG','000006.XSHE','600066.XSHG']:
    cache('price_post_'+code,rqdatac.get_price,order_book_ids=code,
          start_date='2008-12-01',end_date='2026-02-02',frequency='1d',
          fields=['close','volume','total_turnover'],adjust_type='post',skip_suspended=False)
    cache('price_none_'+code,rqdatac.get_price,order_book_ids=code,
          start_date='2008-12-01',end_date='2026-02-02',frequency='1d',
          fields=['close'],adjust_type='none',skip_suspended=False)
cache('ex_factor_verification',rqdatac.get_ex_factor,
      order_book_ids=['600004.XSHG','000006.XSHE','600066.XSHG'],
      start_date='2008-12-01',end_date='2026-02-02')
cache('turnover_verification',rqdatac.get_turnover_rate,
      order_book_ids=['600004.XSHG','000006.XSHE','600066.XSHG'],
      start_date='2022-12-01',end_date='2022-12-30',fields=['today'])
# The overlap audit found isolated one-cent corrections in UNADJUSTED source
# closes, beyond 4-decimal export rounding. Refresh only relevant securities and
# years, rather than silently patch isolated return observations from two vintages.
members_all=pd.concat(all_members,ignore_index=True)
members_all['formation_date']=pd.to_datetime(members_all.formation_date)
for year in range(2008,2027):
    begin=f'{year}-01-01' if year>2008 else '2008-12-01'
    end=f'{year}-12-31' if year<2026 else '2026-02-02'
    required=members_all.loc[members_all.formation_date.between(f'{year-1}-11-01',f'{year+1}-12-31')]
    ids=sorted(required.order_book_id.unique())
    cache(f'prices_{year}',rqdatac.get_price,order_book_ids=ids,
          start_date=begin,end_date=end,frequency='1d',fields=['close','volume','total_turnover'],
          adjust_type='post',skip_suspended=False)
    print('Cached corrected price vintage',year,'securities requested',len(ids),flush=True)
print('RQData collection complete',flush=True)
